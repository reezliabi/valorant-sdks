// BlueprintGeneratedClass AK_Ashen_V3_Streamed.AK_Ashen_V3_Streamed_C
// Size: 0x90 (Inherited: 0x90)
struct UAK_Ashen_V3_Streamed_C : UStreamedVideoDataAsset {
};

