// BlueprintGeneratedClass Ability_Hunter_E_Drone_Abilities_Prototype.Ability_Hunter_E_Drone_Abilities_Prototype_C
// Size: 0x1330 (Inherited: 0x1242)
struct AAbility_Hunter_E_Drone_Abilities_Prototype_C : AAbility_Equipped_Base_C {
	char pad_1242[0x6]; // 0x1242(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1248(0x08)
	struct UTimedStateComponent* TimedState_DartCooldown_Hit; // 0x1250(0x08)
	struct URespondToEventStateComponent* RespondToEventState_FireDart; // 0x1258(0x08)
	struct UStateComp_Hunter_E_LineTraceToCursor_C* StateComp_Hunter_E_LineTraceToCursor; // 0x1260(0x08)
	struct UComp_Actor_MultiTargetHandler_Buff_C* Comp_Actor_MultiTargetHandler_Buff; // 0x1268(0x08)
	struct UCapsuleComponent* LockOnCapsule; // 0x1270(0x08)
	struct USceneComponent* LockOnScene; // 0x1278(0x08)
	struct UScriptStateComponent* ScriptState_DartsFired; // 0x1280(0x08)
	struct UTestBranch_HasValidContextActor_StateComponent_C* TestBranch_HasValidContextActor_StateComponent; // 0x1288(0x08)
	struct UTestBranch_IsCurrentState_StateComponent_C* TestBranch_IsCurrentState_Dart; // 0x1290(0x08)
	struct UTimedStateComponent* TimedState_DartCooldown; // 0x1298(0x08)
	struct UEquippableStateMachineComponent* EquippableStateMachine_Dart; // 0x12a0(0x08)
	struct UDestroyContextActors_StateComponent_C* DestroySelf; // 0x12a8(0x08)
	struct UTimedStateComponent* DroneDuration; // 0x12b0(0x08)
	struct USetOwnerAsContextActor_StateComponent_C* SetOwnerAsContextActor; // 0x12b8(0x08)
	struct UUnpossessSelf_StateComponent_C* UnpossessDrone; // 0x12c0(0x08)
	struct FEffectData FXC_Data_CosmeticProjectile; // 0x12c8(0x58)
	struct TArray<struct AShooterCharacter*> DartedEnemies; // 0x1320(0x10)

	bool CanAutoEquip(); // Function Ability_Hunter_E_Drone_Abilities_Prototype.Ability_Hunter_E_Drone_Abilities_Prototype_C.CanAutoEquip // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x19e0c40
	void ReceiveBeginPlay(); // Function Ability_Hunter_E_Drone_Abilities_Prototype.Ability_Hunter_E_Drone_Abilities_Prototype_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__StateComp_Hunter_E_LineTraceToCursor_K2Node_ComponentBoundEvent_1_OnStateExitSignature__DelegateSignature(struct UScriptStateComponent* ExitedState, struct UStateTransitionContext* StateTransitionContext); // Function Ability_Hunter_E_Drone_Abilities_Prototype.Ability_Hunter_E_Drone_Abilities_Prototype_C.BndEvt__StateComp_Hunter_E_LineTraceToCursor_K2Node_ComponentBoundEvent_1_OnStateExitSignature__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__TimedState_DartCooldown_Hit_K2Node_ComponentBoundEvent_0_OnStateEnterSignature__DelegateSignature(struct UScriptStateComponent* EnteredState, struct UStateTransitionContext* StateTransitionContext, float StartTimeOffset); // Function Ability_Hunter_E_Drone_Abilities_Prototype.Ability_Hunter_E_Drone_Abilities_Prototype_C.BndEvt__TimedState_DartCooldown_Hit_K2Node_ComponentBoundEvent_0_OnStateEnterSignature__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_Ability_Hunter_E_Drone_Abilities_Prototype(int32_t EntryPoint); // Function Ability_Hunter_E_Drone_Abilities_Prototype.Ability_Hunter_E_Drone_Abilities_Prototype_C.ExecuteUbergraph_Ability_Hunter_E_Drone_Abilities_Prototype // (Final|UbergraphFunction|HasDefaults) // @ game+0x19e0c40
};

