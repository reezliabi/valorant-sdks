// BlueprintGeneratedClass AKPrimaryAsset.AKPrimaryAsset_C
// Size: 0x140 (Inherited: 0x140)
struct UAKPrimaryAsset_C : UEquippableDataAsset {
};

