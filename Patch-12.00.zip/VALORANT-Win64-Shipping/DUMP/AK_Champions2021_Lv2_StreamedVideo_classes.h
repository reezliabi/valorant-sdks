// BlueprintGeneratedClass AK_Champions2021_Lv2_StreamedVideo.AK_Champions2021_Lv2_StreamedVideo_C
// Size: 0x90 (Inherited: 0x90)
struct UAK_Champions2021_Lv2_StreamedVideo_C : UStreamedVideoDataAsset {
};

