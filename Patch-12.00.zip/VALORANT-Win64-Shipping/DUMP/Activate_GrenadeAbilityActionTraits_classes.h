// BlueprintGeneratedClass Activate_GrenadeAbilityActionTraits.Activate_GrenadeAbilityActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UActivate_GrenadeAbilityActionTraits_C : UActionTraits {
};

