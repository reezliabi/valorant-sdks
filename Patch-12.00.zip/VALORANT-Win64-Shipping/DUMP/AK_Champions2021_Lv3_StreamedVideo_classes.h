// BlueprintGeneratedClass AK_Champions2021_Lv3_StreamedVideo.AK_Champions2021_Lv3_StreamedVideo_C
// Size: 0x90 (Inherited: 0x90)
struct UAK_Champions2021_Lv3_StreamedVideo_C : UStreamedVideoDataAsset {
};

