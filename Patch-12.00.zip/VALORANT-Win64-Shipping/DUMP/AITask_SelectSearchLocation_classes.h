// BlueprintGeneratedClass AITask_SelectSearchLocation.AITask_SelectSearchLocation_C
// Size: 0x138 (Inherited: 0xb0)
struct UAITask_SelectSearchLocation_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb0(0x08)
	struct TArray<struct AActor*> DestinationOptions; // 0xb8(0x10)
	struct FBlackboardKeySelector DestinationActor; // 0xc8(0x30)
	struct TArray<struct AShooterTeamStart*> StartPoints; // 0xf8(0x10)
	struct TSoftClassPtr<UObject> Test; // 0x108(0x30)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AITask_SelectSearchLocation.AITask_SelectSearchLocation_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AITask_SelectSearchLocation(int32_t EntryPoint); // Function AITask_SelectSearchLocation.AITask_SelectSearchLocation_C.ExecuteUbergraph_AITask_SelectSearchLocation // (Final|UbergraphFunction|HasDefaults) // @ game+0x19e0c40
};

