// BlueprintGeneratedClass AK_Ashen_Lv1_Streamed.AK_Ashen_Lv1_Streamed_C
// Size: 0x90 (Inherited: 0x90)
struct UAK_Ashen_Lv1_Streamed_C : UStreamedVideoDataAsset {
};

