// BlueprintGeneratedClass Accolade_Wushu_KillThroughSmoke_PrimaryAsset.Accolade_Wushu_KillThroughSmoke_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Wushu_KillThroughSmoke_PrimaryAsset_C : UAccoladeDataAsset {
};

