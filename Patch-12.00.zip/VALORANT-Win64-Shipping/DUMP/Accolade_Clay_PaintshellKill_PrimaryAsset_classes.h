// BlueprintGeneratedClass Accolade_Clay_PaintshellKill_PrimaryAsset.Accolade_Clay_PaintshellKill_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Clay_PaintshellKill_PrimaryAsset_C : UAccoladeDataAsset {
};

