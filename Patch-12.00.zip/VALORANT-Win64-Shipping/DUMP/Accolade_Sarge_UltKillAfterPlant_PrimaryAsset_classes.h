// BlueprintGeneratedClass Accolade_Sarge_UltKillAfterPlant_PrimaryAsset.Accolade_Sarge_UltKillAfterPlant_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Sarge_UltKillAfterPlant_PrimaryAsset_C : UAccoladeDataAsset {
};

