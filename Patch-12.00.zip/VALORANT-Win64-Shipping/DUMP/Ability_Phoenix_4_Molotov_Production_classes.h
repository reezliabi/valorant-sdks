// BlueprintGeneratedClass Ability_Phoenix_4_Molotov_Production.Ability_Phoenix_4_Molotov_Production_C
// Size: 0x1298 (Inherited: 0x1284)
struct AAbility_Phoenix_4_Molotov_Production_C : AAbility_Grenade_Base_C {
	char pad_1284[0x4]; // 0x1284(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1288(0x08)
	struct UEquipmentChargeComponent* EquipmentCharge; // 0x1290(0x08)

	void BndEvt__RespondToInputState_K2Node_ComponentBoundEvent_0_OnStateExitSignature__DelegateSignature(struct UScriptStateComponent* ExitedState, struct UStateTransitionContext* StateTransitionContext); // Function Ability_Phoenix_4_Molotov_Production.Ability_Phoenix_4_Molotov_Production_C.BndEvt__RespondToInputState_K2Node_ComponentBoundEvent_0_OnStateExitSignature__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_Ability_Phoenix_4_Molotov_Production(int32_t EntryPoint); // Function Ability_Phoenix_4_Molotov_Production.Ability_Phoenix_4_Molotov_Production_C.ExecuteUbergraph_Ability_Phoenix_4_Molotov_Production // (Final|UbergraphFunction) // @ game+0x19e0c40
};

