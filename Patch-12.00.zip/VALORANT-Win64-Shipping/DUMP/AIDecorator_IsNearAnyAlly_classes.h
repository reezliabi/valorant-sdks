// BlueprintGeneratedClass AIDecorator_IsNearAnyAlly.AIDecorator_IsNearAnyAlly_C
// Size: 0xc1 (Inherited: 0xa8)
struct UAIDecorator_IsNearAnyAlly_C : UBTDecorator_BlueprintBase {
	double Distance; // 0xa8(0x08)
	struct TArray<struct AShooterCharacter*> CachedAllies; // 0xb0(0x10)
	bool bHasCachedAllies; // 0xc0(0x01)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIDecorator_IsNearAnyAlly.AIDecorator_IsNearAnyAlly_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
};

