// BlueprintGeneratedClass Ability_Hunter_Q_RevealBolt_Signature.Ability_Hunter_Q_RevealBolt_Signature_C
// Size: 0x1398 (Inherited: 0x1390)
struct AAbility_Hunter_Q_RevealBolt_Signature_C : AAbility_Hunter_Q_RevealBolt_C {
	struct UComp_Ability_CooldownComponent_C* Comp_Ability_CooldownComponent1; // 0x1390(0x08)
};

