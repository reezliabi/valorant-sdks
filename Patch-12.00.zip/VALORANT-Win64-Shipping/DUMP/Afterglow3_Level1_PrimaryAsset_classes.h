// BlueprintGeneratedClass Afterglow3_Level1_PrimaryAsset.Afterglow3_Level1_PrimaryAsset_C
// Size: 0xf0 (Inherited: 0xf0)
struct UAfterglow3_Level1_PrimaryAsset_C : USprayLevelDataAsset {
};

