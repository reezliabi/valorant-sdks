// BlueprintGeneratedClass Accolade_Clay_ShowstopperKill_PrimaryAsset.Accolade_Clay_ShowstopperKill_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Clay_ShowstopperKill_PrimaryAsset_C : UAccoladeDataAsset {
};

