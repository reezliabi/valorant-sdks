// BlueprintGeneratedClass Accolade_Hunter_KillRevealedWithUlt_PrimaryAsset.Accolade_Hunter_KillRevealedWithUlt_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Hunter_KillRevealedWithUlt_PrimaryAsset_C : UAccoladeDataAsset {
};

