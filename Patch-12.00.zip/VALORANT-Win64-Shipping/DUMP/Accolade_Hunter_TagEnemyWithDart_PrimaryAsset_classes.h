// BlueprintGeneratedClass Accolade_Hunter_TagEnemyWithDart_PrimaryAsset.Accolade_Hunter_TagEnemyWithDart_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Hunter_TagEnemyWithDart_PrimaryAsset_C : UAccoladeDataAsset {
};

