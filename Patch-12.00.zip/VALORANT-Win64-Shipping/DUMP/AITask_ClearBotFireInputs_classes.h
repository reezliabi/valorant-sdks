// BlueprintGeneratedClass AITask_ClearBotFireInputs.AITask_ClearBotFireInputs_C
// Size: 0xc8 (Inherited: 0xb0)
struct UAITask_ClearBotFireInputs_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb0(0x08)
	struct TArray<enum class EAresEquippableInput> Inputs; // 0xb8(0x10)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AITask_ClearBotFireInputs.AITask_ClearBotFireInputs_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AITask_ClearBotFireInputs(int32_t EntryPoint); // Function AITask_ClearBotFireInputs.AITask_ClearBotFireInputs_C.ExecuteUbergraph_AITask_ClearBotFireInputs // (Final|UbergraphFunction) // @ game+0x19e0c40
};

