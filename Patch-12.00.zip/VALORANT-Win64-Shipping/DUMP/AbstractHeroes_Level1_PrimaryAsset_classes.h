// BlueprintGeneratedClass AbstractHeroes_Level1_PrimaryAsset.AbstractHeroes_Level1_PrimaryAsset_C
// Size: 0xf0 (Inherited: 0xf0)
struct UAbstractHeroes_Level1_PrimaryAsset_C : USprayLevelDataAsset {
};

