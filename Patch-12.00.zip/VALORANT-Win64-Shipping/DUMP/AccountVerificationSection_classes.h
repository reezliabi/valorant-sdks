// WidgetBlueprintGeneratedClass AccountVerificationSection.AccountVerificationSection_C
// Size: 0x330 (Inherited: 0x318)
struct UAccountVerificationSection_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x318(0x08)
	struct UVerticalBox* VB_Verify; // 0x320(0x08)
	struct UWBP_MenuButtonPrimary_C* WBP_VerifyButton; // 0x328(0x08)

	void Construct(); // Function AccountVerificationSection.AccountVerificationSection_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__AccountVerificationSection_WBP_VerifyButton_K2Node_ComponentBoundEvent_0_OnUniversalButtonVoidEvent__DelegateSignature(); // Function AccountVerificationSection.AccountVerificationSection_C.BndEvt__AccountVerificationSection_WBP_VerifyButton_K2Node_ComponentBoundEvent_0_OnUniversalButtonVoidEvent__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AccountVerificationSection(int32_t EntryPoint); // Function AccountVerificationSection.AccountVerificationSection_C.ExecuteUbergraph_AccountVerificationSection // (Final|UbergraphFunction) // @ game+0x19e0c40
};

