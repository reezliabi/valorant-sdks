// BlueprintGeneratedClass AK_Anomaly_Lv1_StreamedVideoDataAsset.AK_Anomaly_Lv1_StreamedVideoDataAsset_C
// Size: 0x90 (Inherited: 0x90)
struct UAK_Anomaly_Lv1_StreamedVideoDataAsset_C : UStreamedVideoDataAsset {
};

