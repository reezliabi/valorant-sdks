// BlueprintGeneratedClass Accolade_Pandemic_KillOnDecay_PrimaryAsset.Accolade_Pandemic_KillOnDecay_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Pandemic_KillOnDecay_PrimaryAsset_C : UAccoladeDataAsset {
};

