// BlueprintGeneratedClass Accolade_BountyHunter_NearsightTaggedEnemies_PrimaryAsset.Accolade_BountyHunter_NearsightTaggedEnemies_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_BountyHunter_NearsightTaggedEnemies_PrimaryAsset_C : UAccoladeDataAsset {
};

