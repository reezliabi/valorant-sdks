// BlueprintGeneratedClass AITask_InvalidateBBObject.AITask_InvalidateBBObject_C
// Size: 0xe8 (Inherited: 0xb0)
struct UAITask_InvalidateBBObject_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb0(0x08)
	struct FBlackboardKeySelector ObjectKey; // 0xb8(0x30)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AITask_InvalidateBBObject.AITask_InvalidateBBObject_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AITask_InvalidateBBObject(int32_t EntryPoint); // Function AITask_InvalidateBBObject.AITask_InvalidateBBObject_C.ExecuteUbergraph_AITask_InvalidateBBObject // (Final|UbergraphFunction) // @ game+0x19e0c40
};

