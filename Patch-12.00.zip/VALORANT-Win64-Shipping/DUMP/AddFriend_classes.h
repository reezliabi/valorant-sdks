// WidgetBlueprintGeneratedClass AddFriend.AddFriend_C
// Size: 0x374 (Inherited: 0x318)
struct UAddFriend_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x318(0x08)
	struct USharedButtonMaster_C* AddFriendButton; // 0x320(0x08)
	struct UHorizontalBox* AddFriendContainer; // 0x328(0x08)
	struct UEditableTextBox* AddFriendInput; // 0x330(0x08)
	struct UEditableTextBox* AddTaglineInput; // 0x338(0x08)
	struct UImage* BG; // 0x340(0x08)
	struct UTextBlock* TagPoundSign; // 0x348(0x08)
	struct UImage* White; // 0x350(0x08)
	struct FMulticastInlineDelegate SentFriendRequest; // 0x358(0x10)
	struct FName UseGnT Config; // 0x368(0x0c)

	void ClearInput(); // Function AddFriend.AddFriend_C.ClearInput // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void SendRequest(struct FString& Name, struct FString Tagline); // Function AddFriend.AddFriend_C.SendRequest // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void OnAddFriendTextCommitted(struct FText& Text, enum class ETextCommit CommitMethod); // Function AddFriend.AddFriend_C.OnAddFriendTextCommitted // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void OnAddTaglineTextCommitted(struct FText& Text, enum class ETextCommit CommitMethod); // Function AddFriend.AddFriend_C.OnAddTaglineTextCommitted // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void OnAddGameNameCommited(struct FText& Text, enum class ETextCommit CommitMethod); // Function AddFriend.AddFriend_C.OnAddGameNameCommited // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void OnAddFriendTextChanged(struct FText& Text); // Function AddFriend.AddFriend_C.OnAddFriendTextChanged // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void OnGnTConfigUpdated(struct FName& ConfigName); // Function AddFriend.AddFriend_C.OnGnTConfigUpdated // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void OnAddFriendButton_Clicked(); // Function AddFriend.AddFriend_C.OnAddFriendButton_Clicked // (BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void OnAddFriendButtonGnT_Clicked(); // Function AddFriend.AddFriend_C.OnAddFriendButtonGnT_Clicked // (BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void OnAddFriendInputChanged(struct FText& Text); // Function AddFriend.AddFriend_C.OnAddFriendInputChanged // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void Construct(); // Function AddFriend.AddFriend_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AddFriend(int32_t EntryPoint); // Function AddFriend.AddFriend_C.ExecuteUbergraph_AddFriend // (Final|UbergraphFunction|HasDefaults) // @ game+0x19e0c40
	void SentFriendRequest__DelegateSignature(); // Function AddFriend.AddFriend_C.SentFriendRequest__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
};

