// BlueprintGeneratedClass AK_Commando_Lv3_PrimaryAsset.AK_Commando_Lv3_PrimaryAsset_C
// Size: 0x118 (Inherited: 0x118)
struct UAK_Commando_Lv3_PrimaryAsset_C : UEquippableSkinLevelDataAsset {
};

