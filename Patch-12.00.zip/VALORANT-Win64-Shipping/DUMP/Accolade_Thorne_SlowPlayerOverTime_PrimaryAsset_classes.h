// BlueprintGeneratedClass Accolade_Thorne_SlowPlayerOverTime_PrimaryAsset.Accolade_Thorne_SlowPlayerOverTime_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Thorne_SlowPlayerOverTime_PrimaryAsset_C : UAccoladeDataAsset {
};

