// BlueprintGeneratedClass AK_Brigade_Lv1_PrimaryAsset.AK_Brigade_Lv1_PrimaryAsset_C
// Size: 0x118 (Inherited: 0x118)
struct UAK_Brigade_Lv1_PrimaryAsset_C : UEquippableSkinLevelDataAsset {
};

