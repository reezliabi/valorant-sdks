// BlueprintGeneratedClass AK_Aquarium_Lv2_StreamedVideo.AK_Aquarium_Lv2_StreamedVideo_C
// Size: 0x90 (Inherited: 0x90)
struct UAK_Aquarium_Lv2_StreamedVideo_C : UStreamedVideoDataAsset {
};

