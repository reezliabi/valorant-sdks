// BlueprintGeneratedClass AK_Ashen_v2_PrimaryAsset.AK_Ashen_v2_PrimaryAsset_C
// Size: 0x170 (Inherited: 0x170)
struct UAK_Ashen_v2_PrimaryAsset_C : UEquippableSkinChromaDataAsset {
};

