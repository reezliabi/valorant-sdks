// BlueprintGeneratedClass AggrobotCallSign_Level1_PrimaryAsset.AggrobotCallSign_Level1_PrimaryAsset_C
// Size: 0xf0 (Inherited: 0xf0)
struct UAggrobotCallSign_Level1_PrimaryAsset_C : USprayLevelDataAsset {
};

