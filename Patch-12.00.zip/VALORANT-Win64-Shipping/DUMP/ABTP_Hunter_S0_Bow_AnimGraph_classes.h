// AnimBlueprintGeneratedClass ABTP_Hunter_S0_Bow_AnimGraph.ABTP_Hunter_S0_Bow_AnimGraph_C
// Size: 0x5b0 (Inherited: 0x390)
struct UABTP_Hunter_S0_Bow_AnimGraph_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x390(0x08)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess; // 0x398(0x08)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base; // 0x3a0(0x08)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // 0x3a8(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone; // 0x3c8(0x138)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0x500(0x20)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x520(0x50)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x570(0x20)
	double BowStringAttach3P_Alpha; // 0x590(0x08)
	struct FVector RWeaponLocation; // 0x598(0x18)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABTP_Hunter_S0_Bow_AnimGraph.ABTP_Hunter_S0_Bow_AnimGraph_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABTP_Hunter_S0_Bow_AnimGraph_AnimGraphNode_ModifyBone_09F1192C4AA1B43CE5DF7FA9EE996089(); // Function ABTP_Hunter_S0_Bow_AnimGraph.ABTP_Hunter_S0_Bow_AnimGraph_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABTP_Hunter_S0_Bow_AnimGraph_AnimGraphNode_ModifyBone_09F1192C4AA1B43CE5DF7FA9EE996089 // (BlueprintEvent) // @ game+0x19e0c40
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABTP_Hunter_S0_Bow_AnimGraph.ABTP_Hunter_S0_Bow_AnimGraph_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_ABTP_Hunter_S0_Bow_AnimGraph(int32_t EntryPoint); // Function ABTP_Hunter_S0_Bow_AnimGraph.ABTP_Hunter_S0_Bow_AnimGraph_C.ExecuteUbergraph_ABTP_Hunter_S0_Bow_AnimGraph // (Final|UbergraphFunction|HasDefaults) // @ game+0x19e0c40
};

