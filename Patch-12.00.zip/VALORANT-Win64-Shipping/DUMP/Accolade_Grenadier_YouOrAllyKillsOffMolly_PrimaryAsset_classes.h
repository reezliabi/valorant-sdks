// BlueprintGeneratedClass Accolade_Grenadier_YouOrAllyKillsOffMolly_PrimaryAsset.Accolade_Grenadier_YouOrAllyKillsOffMolly_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Grenadier_YouOrAllyKillsOffMolly_PrimaryAsset_C : UAccoladeDataAsset {
};

