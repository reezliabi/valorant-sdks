// BlueprintGeneratedClass Aberrations_Level1_PrimaryAsset.Aberrations_Level1_PrimaryAsset_C
// Size: 0xf0 (Inherited: 0xf0)
struct UAberrations_Level1_PrimaryAsset_C : USprayLevelDataAsset {
};

