// BlueprintGeneratedClass Accolade_Wraith_KillAfterShortTP_PrimaryAsset.Accolade_Wraith_KillAfterShortTP_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Wraith_KillAfterShortTP_PrimaryAsset_C : UAccoladeDataAsset {
};

