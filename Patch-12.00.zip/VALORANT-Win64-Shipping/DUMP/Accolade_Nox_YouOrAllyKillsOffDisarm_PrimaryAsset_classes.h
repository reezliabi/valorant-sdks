// BlueprintGeneratedClass Accolade_Nox_YouOrAllyKillsOffDisarm_PrimaryAsset.Accolade_Nox_YouOrAllyKillsOffDisarm_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Nox_YouOrAllyKillsOffDisarm_PrimaryAsset_C : UAccoladeDataAsset {
};

