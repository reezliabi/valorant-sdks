// BlueprintGeneratedClass AK_Afterglow_Lv3_Skin.AK_Afterglow_Lv3_Skin_C
// Size: 0x550 (Inherited: 0x518)
struct UAK_Afterglow_Lv3_Skin_C : UAK_Afterglow_Lv2_Skin_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x518(0x08)
	int32_t myCurrentLEDColorSelector; // 0x520(0x04)
	char pad_524[0x4]; // 0x524(0x04)
	struct TArray<struct FColor> myCurrentLEDColors_01; // 0x528(0x10)
	struct FRandomStream myRandomStream; // 0x538(0x18)

	void ReceiveBeginPlay(); // Function AK_Afterglow_Lv3_Skin.AK_Afterglow_Lv3_Skin_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AK_Afterglow_Lv3_Skin(int32_t EntryPoint); // Function AK_Afterglow_Lv3_Skin.AK_Afterglow_Lv3_Skin_C.ExecuteUbergraph_AK_Afterglow_Lv3_Skin // (Final|UbergraphFunction) // @ game+0x19e0c40
};

