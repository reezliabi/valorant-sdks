// BlueprintGeneratedClass AK_Champions2025_Lv1_StreamedVideoDataAsset.AK_Champions2025_Lv1_StreamedVideoDataAsset_C
// Size: 0x90 (Inherited: 0x90)
struct UAK_Champions2025_Lv1_StreamedVideoDataAsset_C : UStreamedVideoDataAsset {
};

