// BlueprintGeneratedClass AbilitiesMission_PrimaryAsset.AbilitiesMission_PrimaryAsset_C
// Size: 0x130 (Inherited: 0x130)
struct UAbilitiesMission_PrimaryAsset_C : UMissionDataAsset {
};

