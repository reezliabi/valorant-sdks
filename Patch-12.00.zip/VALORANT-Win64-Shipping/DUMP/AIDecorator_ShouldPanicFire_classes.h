// BlueprintGeneratedClass AIDecorator_ShouldPanicFire.AIDecorator_ShouldPanicFire_C
// Size: 0xb0 (Inherited: 0xa8)
struct UAIDecorator_ShouldPanicFire_C : UBTDecorator_BlueprintBase {
	double PanicFireOdds; // 0xa8(0x08)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIDecorator_ShouldPanicFire.AIDecorator_ShouldPanicFire_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
};

