// BlueprintGeneratedClass AK_Antares_V2_StreamedVideo.AK_Antares_V2_StreamedVideo_C
// Size: 0x90 (Inherited: 0x90)
struct UAK_Antares_V2_StreamedVideo_C : UStreamedVideoDataAsset {
};

