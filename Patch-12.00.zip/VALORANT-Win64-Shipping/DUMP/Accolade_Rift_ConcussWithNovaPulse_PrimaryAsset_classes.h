// BlueprintGeneratedClass Accolade_Rift_ConcussWithNovaPulse_PrimaryAsset.Accolade_Rift_ConcussWithNovaPulse_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Rift_ConcussWithNovaPulse_PrimaryAsset_C : UAccoladeDataAsset {
};

