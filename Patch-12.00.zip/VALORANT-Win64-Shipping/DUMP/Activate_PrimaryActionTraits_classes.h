// BlueprintGeneratedClass Activate_PrimaryActionTraits.Activate_PrimaryActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UActivate_PrimaryActionTraits_C : UActionTraits {
};

