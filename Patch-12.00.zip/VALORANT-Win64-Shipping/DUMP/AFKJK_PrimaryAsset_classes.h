// BlueprintGeneratedClass AFKJK_PrimaryAsset.AFKJK_PrimaryAsset_C
// Size: 0xd8 (Inherited: 0xd8)
struct UAFKJK_PrimaryAsset_C : USprayDataAsset {
};

