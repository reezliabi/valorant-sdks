// BlueprintGeneratedClass AIDecorator_IsAttacker.AIDecorator_IsAttacker_C
// Size: 0xa8 (Inherited: 0xa8)
struct UAIDecorator_IsAttacker_C : UBTDecorator_BlueprintBase {

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIDecorator_IsAttacker.AIDecorator_IsAttacker_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
};

