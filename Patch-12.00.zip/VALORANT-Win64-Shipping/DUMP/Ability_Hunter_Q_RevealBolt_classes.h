// BlueprintGeneratedClass Ability_Hunter_Q_RevealBolt.Ability_Hunter_Q_RevealBolt_C
// Size: 0x1390 (Inherited: 0x1379)
struct AAbility_Hunter_Q_RevealBolt_C : AAbility_Hunter_BoltParent_C {
	char pad_1379[0x7]; // 0x1379(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1380(0x08)
	struct UEquipmentChargeComponent* EquipmentCharge; // 0x1388(0x08)

	void ReceiveBeginPlay(); // Function Ability_Hunter_Q_RevealBolt.Ability_Hunter_Q_RevealBolt_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_Ability_Hunter_Q_RevealBolt(int32_t EntryPoint); // Function Ability_Hunter_Q_RevealBolt.Ability_Hunter_Q_RevealBolt_C.ExecuteUbergraph_Ability_Hunter_Q_RevealBolt // (Final|UbergraphFunction) // @ game+0x19e0c40
};

