// BlueprintGeneratedClass AK_Champions2023_PrimaryAsset.AK_Champions2023_PrimaryAsset_C
// Size: 0x220 (Inherited: 0x220)
struct UAK_Champions2023_PrimaryAsset_C : UEquippableSkinDataAsset {
};

