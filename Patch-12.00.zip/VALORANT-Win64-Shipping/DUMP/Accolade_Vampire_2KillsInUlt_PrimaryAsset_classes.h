// BlueprintGeneratedClass Accolade_Vampire_2KillsInUlt_PrimaryAsset.Accolade_Vampire_2KillsInUlt_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Vampire_2KillsInUlt_PrimaryAsset_C : UAccoladeDataAsset {
};

