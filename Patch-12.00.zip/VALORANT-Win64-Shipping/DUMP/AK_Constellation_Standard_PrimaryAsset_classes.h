// BlueprintGeneratedClass AK_Constellation_Standard_PrimaryAsset.AK_Constellation_Standard_PrimaryAsset_C
// Size: 0x170 (Inherited: 0x170)
struct UAK_Constellation_Standard_PrimaryAsset_C : UEquippableSkinChromaDataAsset {
};

