// BlueprintGeneratedClass Afterglow2_KillCounterInterface.Afterglow2_KillCounterInterface_C
// Size: 0x30 (Inherited: 0x30)
struct UAfterglow2_KillCounterInterface_C : UInterface {

	void Afterglow2_GetKillCounterDynamicMaterials(struct UMaterialInstanceDynamic*& KillCounterDigit1, struct UMaterialInstanceDynamic*& KillCounterDigit2, struct UMaterialInstanceDynamic*& KillCounterBrackets, struct UMaterialInstanceDynamic*& KillCounterProjection); // Function Afterglow2_KillCounterInterface.Afterglow2_KillCounterInterface_C.Afterglow2_GetKillCounterDynamicMaterials // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
};

