// BlueprintGeneratedClass Accolade_Guide_FlashMultipleEnemies_PrimaryAsset.Accolade_Guide_FlashMultipleEnemies_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Guide_FlashMultipleEnemies_PrimaryAsset_C : UAccoladeDataAsset {
};

