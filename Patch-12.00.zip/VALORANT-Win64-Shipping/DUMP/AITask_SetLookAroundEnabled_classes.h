// BlueprintGeneratedClass AITask_SetLookAroundEnabled.AITask_SetLookAroundEnabled_C
// Size: 0xe0 (Inherited: 0xb0)
struct UAITask_SetLookAroundEnabled_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb0(0x08)
	bool Enabled; // 0xb8(0x01)
	char pad_B9[0x7]; // 0xb9(0x07)
	double YawAngleVariance; // 0xc0(0x08)
	double PitchAngleVariance; // 0xc8(0x08)
	double MovingYawAngleVariance; // 0xd0(0x08)
	double MovingPitchAngleVariance; // 0xd8(0x08)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AITask_SetLookAroundEnabled.AITask_SetLookAroundEnabled_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AITask_SetLookAroundEnabled(int32_t EntryPoint); // Function AITask_SetLookAroundEnabled.AITask_SetLookAroundEnabled_C.ExecuteUbergraph_AITask_SetLookAroundEnabled // (Final|UbergraphFunction) // @ game+0x19e0c40
};

