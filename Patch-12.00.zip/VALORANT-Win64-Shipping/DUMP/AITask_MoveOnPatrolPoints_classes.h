// BlueprintGeneratedClass AITask_MoveOnPatrolPoints.AITask_MoveOnPatrolPoints_C
// Size: 0xe8 (Inherited: 0xb0)
struct UAITask_MoveOnPatrolPoints_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb0(0x08)
	struct FBlackboardKeySelector FocalLocation; // 0xb8(0x30)

	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function AITask_MoveOnPatrolPoints.AITask_MoveOnPatrolPoints_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ReceiveAbortAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AITask_MoveOnPatrolPoints.AITask_MoveOnPatrolPoints_C.ReceiveAbortAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AITask_MoveOnPatrolPoints(int32_t EntryPoint); // Function AITask_MoveOnPatrolPoints.AITask_MoveOnPatrolPoints_C.ExecuteUbergraph_AITask_MoveOnPatrolPoints // (Final|UbergraphFunction) // @ game+0x19e0c40
};

