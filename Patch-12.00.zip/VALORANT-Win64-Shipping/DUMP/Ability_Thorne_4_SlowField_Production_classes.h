// BlueprintGeneratedClass Ability_Thorne_4_SlowField_Production.Ability_Thorne_4_SlowField_Production_C
// Size: 0x12b8 (Inherited: 0x1284)
struct AAbility_Thorne_4_SlowField_Production_C : AAbility_Grenade_Base_C {
	char pad_1284[0x4]; // 0x1284(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1288(0x08)
	struct UEquipmentChargeComponent* EquipmentCharge; // 0x1290(0x08)
	struct FEffectID FXC_ID_EquippedUntilFire; // 0x1298(0x20)

	void AuthOnEquipped(); // Function Ability_Thorne_4_SlowField_Production.Ability_Thorne_4_SlowField_Production_C.AuthOnEquipped // (BlueprintAuthorityOnly|Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void AuthOnUnEquipped(); // Function Ability_Thorne_4_SlowField_Production.Ability_Thorne_4_SlowField_Production_C.AuthOnUnEquipped // (BlueprintAuthorityOnly|Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__OverhandThrowState_K2Node_ComponentBoundEvent_0_OnThrow__DelegateSignature(struct UProjectileThrowStateComponent* ThrowState, struct TArray<struct AProjectile*>& Projectiles); // Function Ability_Thorne_4_SlowField_Production.Ability_Thorne_4_SlowField_Production_C.BndEvt__OverhandThrowState_K2Node_ComponentBoundEvent_0_OnThrow__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__UnderhandThrowState_K2Node_ComponentBoundEvent_1_OnThrow__DelegateSignature(struct UProjectileThrowStateComponent* ThrowState, struct TArray<struct AProjectile*>& Projectiles); // Function Ability_Thorne_4_SlowField_Production.Ability_Thorne_4_SlowField_Production_C.BndEvt__UnderhandThrowState_K2Node_ComponentBoundEvent_1_OnThrow__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_Ability_Thorne_4_SlowField_Production(int32_t EntryPoint); // Function Ability_Thorne_4_SlowField_Production.Ability_Thorne_4_SlowField_Production_C.ExecuteUbergraph_Ability_Thorne_4_SlowField_Production // (Final|UbergraphFunction|HasDefaults) // @ game+0x19e0c40
};

