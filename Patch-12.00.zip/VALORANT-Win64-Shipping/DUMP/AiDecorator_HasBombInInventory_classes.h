// BlueprintGeneratedClass AiDecorator_HasBombInInventory.AiDecorator_HasBombInInventory_C
// Size: 0xa8 (Inherited: 0xa8)
struct UAiDecorator_HasBombInInventory_C : UBTDecorator_BlueprintBase {

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AiDecorator_HasBombInInventory.AiDecorator_HasBombInInventory_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
};

