// BlueprintGeneratedClass AK_Antares_Lv2_StreamedVideo.AK_Antares_Lv2_StreamedVideo_C
// Size: 0x90 (Inherited: 0x90)
struct UAK_Antares_Lv2_StreamedVideo_C : UStreamedVideoDataAsset {
};

