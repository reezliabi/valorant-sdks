// AnimBlueprintGeneratedClass AB_Wushu_Melee_Knife_AnimBP.AB_Wushu_Melee_Knife_AnimBP_C
// Size: 0x460 (Inherited: 0x390)
struct UAB_Wushu_Melee_Knife_AnimBP_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x390(0x08)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess; // 0x398(0x08)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base; // 0x3a0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x3a8(0x20)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x3c8(0x50)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x418(0x48)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function AB_Wushu_Melee_Knife_AnimBP.AB_Wushu_Melee_Knife_AnimBP_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AB_Wushu_Melee_Knife_AnimBP(int32_t EntryPoint); // Function AB_Wushu_Melee_Knife_AnimBP.AB_Wushu_Melee_Knife_AnimBP_C.ExecuteUbergraph_AB_Wushu_Melee_Knife_AnimBP // (Final|UbergraphFunction) // @ game+0x19e0c40
};

