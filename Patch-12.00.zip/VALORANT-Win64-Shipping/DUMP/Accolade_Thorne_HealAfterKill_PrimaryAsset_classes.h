// BlueprintGeneratedClass Accolade_Thorne_HealAfterKill_PrimaryAsset.Accolade_Thorne_HealAfterKill_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Thorne_HealAfterKill_PrimaryAsset_C : UAccoladeDataAsset {
};

