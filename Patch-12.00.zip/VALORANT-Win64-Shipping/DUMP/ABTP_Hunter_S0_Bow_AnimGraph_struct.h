// ScriptStruct ABTP_Hunter_S0_Bow_AnimGraph.ABTP_Hunter_S0_Bow_AnimGraph_C.AnimBlueprintGeneratedConstantData
// Size: 0xe0 (Inherited: 0x01)
struct FAnimBlueprintGeneratedConstantData : FAnimBlueprintConstantData {
	char pad_1[0x7]; // 0x01(0x07)
	struct FAnimNodeFunctionRef __StructProperty_14; // 0x08(0x28)
	struct FName __NameProperty_15; // 0x30(0x0c)
	struct FName __NameProperty_16; // 0x3c(0x0c)
	struct FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess; // 0x48(0x80)
	struct FAnimSubsystem_Base AnimBlueprintExtension_Base; // 0xc8(0x18)
};

// ScriptStruct ABTP_Hunter_S0_Bow_AnimGraph.ABTP_Hunter_S0_Bow_AnimGraph_C.AnimBlueprintGeneratedMutableData
// Size: 0x01 (Inherited: 0x01)
struct FAnimBlueprintGeneratedMutableData : FAnimBlueprintMutableData {
};

