// BlueprintGeneratedClass AITask_SetBool.AITask_SetBool_C
// Size: 0xe9 (Inherited: 0xb0)
struct UAITask_SetBool_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb0(0x08)
	struct FBlackboardKeySelector BoolKey; // 0xb8(0x30)
	bool Value; // 0xe8(0x01)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AITask_SetBool.AITask_SetBool_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AITask_SetBool(int32_t EntryPoint); // Function AITask_SetBool.AITask_SetBool_C.ExecuteUbergraph_AITask_SetBool // (Final|UbergraphFunction) // @ game+0x19e0c40
};

