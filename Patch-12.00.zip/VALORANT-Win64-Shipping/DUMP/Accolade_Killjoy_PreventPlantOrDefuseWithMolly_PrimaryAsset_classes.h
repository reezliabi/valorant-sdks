// BlueprintGeneratedClass Accolade_Killjoy_PreventPlantOrDefuseWithMolly_PrimaryAsset.Accolade_Killjoy_PreventPlantOrDefuseWithMolly_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Killjoy_PreventPlantOrDefuseWithMolly_PrimaryAsset_C : UAccoladeDataAsset {
};

