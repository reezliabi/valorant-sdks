// AnimBlueprintGeneratedClass ABTP_Wushu_S0_AnimGraph.ABTP_Wushu_S0_AnimGraph_C
// Size: 0x460 (Inherited: 0x390)
struct UABTP_Wushu_S0_AnimGraph_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x390(0x08)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess; // 0x398(0x08)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base; // 0x3a0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x3a8(0x20)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x3c8(0x50)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x418(0x48)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABTP_Wushu_S0_AnimGraph.ABTP_Wushu_S0_AnimGraph_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_ABTP_Wushu_S0_AnimGraph(int32_t EntryPoint); // Function ABTP_Wushu_S0_AnimGraph.ABTP_Wushu_S0_AnimGraph_C.ExecuteUbergraph_ABTP_Wushu_S0_AnimGraph // (Final|UbergraphFunction) // @ game+0x19e0c40
};

