// BlueprintGeneratedClass AbstractHeroes_PrimaryAsset.AbstractHeroes_PrimaryAsset_C
// Size: 0xd8 (Inherited: 0xd8)
struct UAbstractHeroes_PrimaryAsset_C : USprayDataAsset {
};

