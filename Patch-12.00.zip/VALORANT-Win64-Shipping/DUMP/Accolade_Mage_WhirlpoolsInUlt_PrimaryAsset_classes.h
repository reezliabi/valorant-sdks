// BlueprintGeneratedClass Accolade_Mage_WhirlpoolsInUlt_PrimaryAsset.Accolade_Mage_WhirlpoolsInUlt_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Mage_WhirlpoolsInUlt_PrimaryAsset_C : UAccoladeDataAsset {
};

