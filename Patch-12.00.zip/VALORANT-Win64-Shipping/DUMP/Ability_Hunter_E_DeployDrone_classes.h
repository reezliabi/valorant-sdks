// BlueprintGeneratedClass Ability_Hunter_E_DeployDrone.Ability_Hunter_E_DeployDrone_C
// Size: 0x1301 (Inherited: 0x1242)
struct AAbility_Hunter_E_DeployDrone_C : AAbility_Equipped_Base_C {
	char pad_1242[0x6]; // 0x1242(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1248(0x08)
	struct UAresOutlineComponent* Outline1P; // 0x1250(0x08)
	struct UAresOutlineComponent* Outline3P; // 0x1258(0x08)
	struct UStateComponent_WaitForSpawnedCharacterToBePossessed_C* StateComponent_WaitForSpawnedCharacterToBePossessed; // 0x1260(0x08)
	struct UTimedStateComponent* DeployDelay; // 0x1268(0x08)
	struct URespondToEventStateComponent* RespondToEventState_Deploy; // 0x1270(0x08)
	struct UFindSpawnSpotStateComponent* FindSpawnSpotState; // 0x1278(0x08)
	struct UPossessContextActor_StateComponent_C* PossessContextActor_StateComponent; // 0x1280(0x08)
	struct UEquipmentChargeComponent* EquipmentCharge; // 0x1288(0x08)
	struct UConsumeResourcesStateComponent* ConsumeResourcesState; // 0x1290(0x08)
	struct USpawnActorStateComponent* SpawnActorState; // 0x1298(0x08)
	struct UWaitForEquipStateComponent* WaitForEquipState; // 0x12a0(0x08)
	struct FName EquippableCosmeticAttachPoint3P; // 0x12a8(0x0c)
	struct FName EquippableCosmeticAttachPoint1P; // 0x12b4(0x0c)
	struct FEffectID FXC_ID_ShowArmDrone; // 0x12c0(0x20)
	struct FEffectID FXC_ID_EquippedUntilThrown; // 0x12e0(0x20)
	bool ArmVisualsActive; // 0x1300(0x01)

	void UpdateArmVisuals(struct AShooterCharacter* InShooterCharacter); // Function Ability_Hunter_E_DeployDrone.Ability_Hunter_E_DeployDrone_C.UpdateArmVisuals // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void ReceiveBeginPlay(); // Function Ability_Hunter_E_DeployDrone.Ability_Hunter_E_DeployDrone_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__EquipmentCharge_K2Node_ComponentBoundEvent_1_ResourceChanged__DelegateSignature(struct UResourceComponent* ResourceComponent); // Function Ability_Hunter_E_DeployDrone.Ability_Hunter_E_DeployDrone_C.BndEvt__EquipmentCharge_K2Node_ComponentBoundEvent_1_ResourceChanged__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void AuthOnEquipped(); // Function Ability_Hunter_E_DeployDrone.Ability_Hunter_E_DeployDrone_C.AuthOnEquipped // (BlueprintAuthorityOnly|Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void AuthOnUnEquipped(); // Function Ability_Hunter_E_DeployDrone.Ability_Hunter_E_DeployDrone_C.AuthOnUnEquipped // (BlueprintAuthorityOnly|Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ReceiveAuthSetOwningCharacter(struct AShooterCharacter* NewCharacter); // Function Ability_Hunter_E_DeployDrone.Ability_Hunter_E_DeployDrone_C.ReceiveAuthSetOwningCharacter // (BlueprintAuthorityOnly|Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__ConsumeResourcesState_K2Node_ComponentBoundEvent_0_OnStateEnterSignature__DelegateSignature(struct UScriptStateComponent* EnteredState, struct UStateTransitionContext* StateTransitionContext, float StartTimeOffset); // Function Ability_Hunter_E_DeployDrone.Ability_Hunter_E_DeployDrone_C.BndEvt__ConsumeResourcesState_K2Node_ComponentBoundEvent_0_OnStateEnterSignature__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void ItemOnSetOwner_Event_2(struct AAresItem* Item, struct AActor* PrevOwner, struct AActor* NewOwner); // Function Ability_Hunter_E_DeployDrone.Ability_Hunter_E_DeployDrone_C.ItemOnSetOwner_Event_2 // (BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__SpawnActorState_K2Node_ComponentBoundEvent_2_OnSpawnActor__DelegateSignature(struct USpawnActorStateComponent* SpawnState, struct AActor* SpawnedActor); // Function Ability_Hunter_E_DeployDrone.Ability_Hunter_E_DeployDrone_C.BndEvt__SpawnActorState_K2Node_ComponentBoundEvent_2_OnSpawnActor__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void OnMeshVisibilityUpdated_Event(struct AAresEquippable* Equippable, bool bFirstPersonVisible, bool bThirdPersonVisible); // Function Ability_Hunter_E_DeployDrone.Ability_Hunter_E_DeployDrone_C.OnMeshVisibilityUpdated_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_Ability_Hunter_E_DeployDrone(int32_t EntryPoint); // Function Ability_Hunter_E_DeployDrone.Ability_Hunter_E_DeployDrone_C.ExecuteUbergraph_Ability_Hunter_E_DeployDrone // (Final|UbergraphFunction|HasDefaults) // @ game+0x19e0c40
};

