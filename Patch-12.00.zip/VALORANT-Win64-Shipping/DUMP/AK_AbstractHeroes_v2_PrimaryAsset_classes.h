// BlueprintGeneratedClass AK_AbstractHeroes_v2_PrimaryAsset.AK_AbstractHeroes_v2_PrimaryAsset_C
// Size: 0x170 (Inherited: 0x170)
struct UAK_AbstractHeroes_v2_PrimaryAsset_C : UEquippableSkinChromaDataAsset {
};

