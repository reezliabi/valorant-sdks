// BlueprintGeneratedClass AiDecorator_IsBlinded.AiDecorator_IsBlinded_C
// Size: 0xd8 (Inherited: 0xa8)
struct UAiDecorator_IsBlinded_C : UBTDecorator_BlueprintBase {
	struct FBlackboardKeySelector PlaceholderBBKeyVar_DoNotDelete; // 0xa8(0x30)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AiDecorator_IsBlinded.AiDecorator_IsBlinded_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
};

