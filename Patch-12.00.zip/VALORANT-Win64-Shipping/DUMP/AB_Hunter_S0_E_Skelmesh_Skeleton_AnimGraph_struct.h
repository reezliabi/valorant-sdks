// ScriptStruct AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph.AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph_C.AnimBlueprintGeneratedConstantData
// Size: 0x138 (Inherited: 0x01)
struct FAnimBlueprintGeneratedConstantData : FAnimBlueprintConstantData {
	char pad_1[0x3]; // 0x01(0x03)
	struct FName __NameProperty_81; // 0x04(0x0c)
	struct FName __NameProperty_82; // 0x10(0x0c)
	int32_t __IntProperty_83; // 0x1c(0x04)
	bool __BoolProperty_84; // 0x20(0x01)
	char pad_21[0x3]; // 0x21(0x03)
	float __FloatProperty_85; // 0x24(0x04)
	struct FInputScaleBiasClampConstants __StructProperty_86; // 0x28(0x2c)
	float __FloatProperty_87; // 0x54(0x04)
	bool __BoolProperty_88; // 0x58(0x01)
	enum class EAnimSyncMethod __EnumProperty_89; // 0x59(0x01)
	enum class EAnimGroupRole __ByteProperty_90; // 0x5a(0x01)
	char pad_5B[0x1]; // 0x5b(0x01)
	struct FName __NameProperty_91; // 0x5c(0x0c)
	struct FName __NameProperty_92; // 0x68(0x0c)
	int32_t __IntProperty_93; // 0x74(0x04)
	struct FAnimNodeFunctionRef __StructProperty_94; // 0x78(0x28)
	struct FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess; // 0xa0(0x80)
	struct FAnimSubsystem_Base AnimBlueprintExtension_Base; // 0x120(0x18)
};

// ScriptStruct AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph.AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph_C.AnimBlueprintGeneratedMutableData
// Size: 0x0c (Inherited: 0x01)
struct FAnimBlueprintGeneratedMutableData : FAnimBlueprintMutableData {
	char pad_1[0x3]; // 0x01(0x03)
	float __FloatProperty; // 0x04(0x04)
	float __FloatProperty_1; // 0x08(0x04)
};

