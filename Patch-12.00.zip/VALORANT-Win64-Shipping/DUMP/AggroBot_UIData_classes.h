// BlueprintGeneratedClass AggroBot_UIData.AggroBot_UIData_C
// Size: 0x2d8 (Inherited: 0x2d8)
struct UAggroBot_UIData_C : UCharacterUIData {
};

