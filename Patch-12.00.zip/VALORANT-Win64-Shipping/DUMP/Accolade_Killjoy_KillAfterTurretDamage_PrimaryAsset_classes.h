// BlueprintGeneratedClass Accolade_Killjoy_KillAfterTurretDamage_PrimaryAsset.Accolade_Killjoy_KillAfterTurretDamage_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Killjoy_KillAfterTurretDamage_PrimaryAsset_C : UAccoladeDataAsset {
};

