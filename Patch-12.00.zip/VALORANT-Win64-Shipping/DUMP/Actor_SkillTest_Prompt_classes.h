// BlueprintGeneratedClass Actor_SkillTest_Prompt.Actor_SkillTest_Prompt_C
// Size: 0x598 (Inherited: 0x4b0)
struct AActor_SkillTest_Prompt_C : AGameObject {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4b0(0x08)
	struct UWidgetComponent_InWorldText_C* WidgetComponent_InWorldText_ShootPrompt; // 0x4b8(0x08)
	struct UWidgetComponent_InWorldText_C* WidgetComponent_InWorldText_Description; // 0x4c0(0x08)
	struct UWidgetComponent_InWorldText_C* WidgetComponent_InWorldText_SkillTest; // 0x4c8(0x08)
	struct UWidgetComponent_InWorldText_C* WidgetComponent_InWorldText_TestTitle; // 0x4d0(0x08)
	struct UStaticMeshComponent* Crosshair; // 0x4d8(0x08)
	struct UStaticMeshComponent* Gameplay_0_LineA; // 0x4e0(0x08)
	struct UAresTextRenderComponent* Text_Countdown; // 0x4e8(0x08)
	struct USceneComponent* Switch_Marker; // 0x4f0(0x08)
	struct UAresTextRenderComponent* Text_TestTitle; // 0x4f8(0x08)
	struct UAresTextRenderComponent* Text_ShootPrompt; // 0x500(0x08)
	struct UAresTextRenderComponent* Text_Description; // 0x508(0x08)
	struct UAresTextRenderComponent* Text_TestNumber; // 0x510(0x08)
	struct UAresTextRenderComponent* Text_SkillTest; // 0x518(0x08)
	struct FMulticastInlineDelegate OnStartRequested; // 0x520(0x10)
	struct FText SkillTestDescription; // 0x530(0x18)
	struct FText SkillTestTitle; // 0x548(0x18)
	struct AShootableSwitch_C* SWITCH; // 0x560(0x08)
	int32_t CountdownRemaining; // 0x568(0x04)
	char pad_56C[0x4]; // 0x56c(0x04)
	double CountdownTickRate; // 0x570(0x08)
	struct FTimerHandle ChallengeTimerHandle; // 0x578(0x08)
	struct FText SkillTestIndexString; // 0x580(0x18)

	void InitializeTestTitle(); // Function Actor_SkillTest_Prompt.Actor_SkillTest_Prompt_C.InitializeTestTitle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void InitializeDescription(); // Function Actor_SkillTest_Prompt.Actor_SkillTest_Prompt_C.InitializeDescription // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void InitializeTestNumber(); // Function Actor_SkillTest_Prompt.Actor_SkillTest_Prompt_C.InitializeTestNumber // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void InitializeSwitch(); // Function Actor_SkillTest_Prompt.Actor_SkillTest_Prompt_C.InitializeSwitch // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void ReceiveBeginPlay(); // Function Actor_SkillTest_Prompt.Actor_SkillTest_Prompt_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void Event Auth Switch Shot(struct AShootableSwitch_C* SwitchAction, struct AActor* DamageCauser); // Function Actor_SkillTest_Prompt.Actor_SkillTest_Prompt_C.Event Auth Switch Shot // (BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void ReceiveDestroyed(); // Function Actor_SkillTest_Prompt.Actor_SkillTest_Prompt_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0x19e0c40
	void Multicast Start Switch Shot(); // Function Actor_SkillTest_Prompt.Actor_SkillTest_Prompt_C.Multicast Start Switch Shot // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void Multicast Countdown Ping(int32_t Value); // Function Actor_SkillTest_Prompt.Actor_SkillTest_Prompt_C.Multicast Countdown Ping // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void Multicast Countdown Finish(); // Function Actor_SkillTest_Prompt.Actor_SkillTest_Prompt_C.Multicast Countdown Finish // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void Event Countdown(); // Function Actor_SkillTest_Prompt.Actor_SkillTest_Prompt_C.Event Countdown // (BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void Event Countdown Finished(); // Function Actor_SkillTest_Prompt.Actor_SkillTest_Prompt_C.Event Countdown Finished // (BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_Actor_SkillTest_Prompt(int32_t EntryPoint); // Function Actor_SkillTest_Prompt.Actor_SkillTest_Prompt_C.ExecuteUbergraph_Actor_SkillTest_Prompt // (Final|UbergraphFunction|HasDefaults) // @ game+0x19e0c40
	void OnStartRequested__DelegateSignature(); // Function Actor_SkillTest_Prompt.Actor_SkillTest_Prompt_C.OnStartRequested__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
};

