// BlueprintGeneratedClass AIDecorator_CurrentTargetShootableFlash.AIDecorator_CurrentTargetShootableFlash_C
// Size: 0xd8 (Inherited: 0xa8)
struct UAIDecorator_CurrentTargetShootableFlash_C : UBTDecorator_BlueprintBase {
	struct FBlackboardKeySelector CurrentTargetKey; // 0xa8(0x30)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIDecorator_CurrentTargetShootableFlash.AIDecorator_CurrentTargetShootableFlash_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
};

