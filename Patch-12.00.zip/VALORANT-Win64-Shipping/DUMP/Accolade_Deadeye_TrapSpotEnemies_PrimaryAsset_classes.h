// BlueprintGeneratedClass Accolade_Deadeye_TrapSpotEnemies_PrimaryAsset.Accolade_Deadeye_TrapSpotEnemies_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Deadeye_TrapSpotEnemies_PrimaryAsset_C : UAccoladeDataAsset {
};

