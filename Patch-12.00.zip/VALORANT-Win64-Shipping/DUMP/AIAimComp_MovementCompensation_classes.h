// BlueprintGeneratedClass AIAimComp_MovementCompensation.AIAimComp_MovementCompensation_C
// Size: 0x1e3 (Inherited: 0xd8)
struct UAIAimComp_MovementCompensation_C : UActorComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd8(0x08)
	struct UAresBotDebugComponent* DebugComponent; // 0xe0(0x08)
	struct AShooterCharacter* TargetShooterCharacter; // 0xe8(0x08)
	double LatestTimestamp; // 0xf0(0x08)
	double MovementDeltaTime; // 0xf8(0x08)
	struct FVector LatestLocation; // 0x100(0x18)
	struct FVector LatestVelocity; // 0x118(0x18)
	double PrevTimestamp; // 0x130(0x08)
	struct FVector PrevLocation; // 0x138(0x18)
	struct FVector PrevVelocity; // 0x150(0x18)
	struct FTimerHandle TimerHandle; // 0x168(0x08)
	struct FVector PredictedLocation; // 0x170(0x18)
	struct FVector PredictedVelocity; // 0x188(0x18)
	double LastUpdateLocationTime; // 0x1a0(0x08)
	struct UCurveFloat* VelocityLerpSinceReactionCurve; // 0x1a8(0x08)
	double MeanReactionTime; // 0x1b0(0x08)
	int32_t PredictedLocationLineId; // 0x1b8(0x04)
	int32_t PredictedLocationSphereId; // 0x1bc(0x04)
	int32_t LatestVelocityLineId; // 0x1c0(0x04)
	int32_t LatestVelocitySphereId; // 0x1c4(0x04)
	int32_t PredictedVelocityLineId; // 0x1c8(0x04)
	int32_t PredictedVelocitySphereId; // 0x1cc(0x04)
	double DistanceDeltaForWrongPrediction; // 0x1d0(0x08)
	double ReactionTimeStdDevFactor; // 0x1d8(0x08)
	bool ValidPrevLocation; // 0x1e0(0x01)
	bool ValidLatestVelocity; // 0x1e1(0x01)
	bool ValidPredictedVelocity; // 0x1e2(0x01)

	void InvalidateStateOnTargetSwitch(); // Function AIAimComp_MovementCompensation.AIAimComp_MovementCompensation_C.InvalidateStateOnTargetSwitch // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void MatchPositionIfInvalidPrediction(); // Function AIAimComp_MovementCompensation.AIAimComp_MovementCompensation_C.MatchPositionIfInvalidPrediction // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void SetPrevInfo(); // Function AIAimComp_MovementCompensation.AIAimComp_MovementCompensation_C.SetPrevInfo // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void DebugDrawing(); // Function AIAimComp_MovementCompensation.AIAimComp_MovementCompensation_C.DebugDrawing // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void PostReactionVelocityTacking(); // Function AIAimComp_MovementCompensation.AIAimComp_MovementCompensation_C.PostReactionVelocityTacking // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void TriggerReactionTimerOnWrongPrediction(); // Function AIAimComp_MovementCompensation.AIAimComp_MovementCompensation_C.TriggerReactionTimerOnWrongPrediction // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void UpdatePredictedLocation(); // Function AIAimComp_MovementCompensation.AIAimComp_MovementCompensation_C.UpdatePredictedLocation // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void UpdateLatest(struct FVector TargetLocation); // Function AIAimComp_MovementCompensation.AIAimComp_MovementCompensation_C.UpdateLatest // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void MatchPosition(); // Function AIAimComp_MovementCompensation.AIAimComp_MovementCompensation_C.MatchPosition // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void CompensateForTargetMovement(struct AActor* TargetActor, struct FVector TargetLocation, double DeltaTime, struct FVector& AimLocation, struct FVector& PredictedVelocity, double& PredictionDeltaTime, bool& bValidPrediction); // Function AIAimComp_MovementCompensation.AIAimComp_MovementCompensation_C.CompensateForTargetMovement // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void ReceiveBeginPlay(); // Function AIAimComp_MovementCompensation.AIAimComp_MovementCompensation_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AIAimComp_MovementCompensation(int32_t EntryPoint); // Function AIAimComp_MovementCompensation.AIAimComp_MovementCompensation_C.ExecuteUbergraph_AIAimComp_MovementCompensation // (Final|UbergraphFunction) // @ game+0x19e0c40
};

