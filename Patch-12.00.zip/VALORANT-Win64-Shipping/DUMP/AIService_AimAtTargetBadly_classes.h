// BlueprintGeneratedClass AIService_AimAtTargetBadly.AIService_AimAtTargetBadly_C
// Size: 0xf0 (Inherited: 0xa0)
struct UAIService_AimAtTargetBadly_C : UBTService_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa0(0x08)
	struct FBlackboardKeySelector FocusObject; // 0xa8(0x30)
	double Deviation; // 0xd8(0x08)
	double MinCycleSpeed; // 0xe0(0x08)
	double MaxCycleSpeed; // 0xe8(0x08)

	void ReceiveDeactivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIService_AimAtTargetBadly.AIService_AimAtTargetBadly_C.ReceiveDeactivationAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function AIService_AimAtTargetBadly.AIService_AimAtTargetBadly_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ReceiveActivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIService_AimAtTargetBadly.AIService_AimAtTargetBadly_C.ReceiveActivationAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AIService_AimAtTargetBadly(int32_t EntryPoint); // Function AIService_AimAtTargetBadly.AIService_AimAtTargetBadly_C.ExecuteUbergraph_AIService_AimAtTargetBadly // (Final|UbergraphFunction) // @ game+0x19e0c40
};

