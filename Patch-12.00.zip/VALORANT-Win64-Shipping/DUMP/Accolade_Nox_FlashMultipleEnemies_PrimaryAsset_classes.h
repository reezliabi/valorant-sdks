// BlueprintGeneratedClass Accolade_Nox_FlashMultipleEnemies_PrimaryAsset.Accolade_Nox_FlashMultipleEnemies_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Nox_FlashMultipleEnemies_PrimaryAsset_C : UAccoladeDataAsset {
};

