// BlueprintGeneratedClass 8BitVAL_PrimaryAsset.8BitVAL_PrimaryAsset_C
// Size: 0xd8 (Inherited: 0xd8)
struct U8BitVAL_PrimaryAsset_C : USprayDataAsset {
};

