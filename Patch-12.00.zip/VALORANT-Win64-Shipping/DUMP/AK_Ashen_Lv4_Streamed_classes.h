// BlueprintGeneratedClass AK_Ashen_Lv4_Streamed.AK_Ashen_Lv4_Streamed_C
// Size: 0x90 (Inherited: 0x90)
struct UAK_Ashen_Lv4_Streamed_C : UStreamedVideoDataAsset {
};

