// BlueprintGeneratedClass Activate_Ability2ActionTraits.Activate_Ability2ActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UActivate_Ability2ActionTraits_C : UActionTraits {
};

