// BlueprintGeneratedClass AgentFusion_YoruPheonix_PrimaryAsset.AgentFusion_YoruPheonix_PrimaryAsset_C
// Size: 0xd8 (Inherited: 0xd8)
struct UAgentFusion_YoruPheonix_PrimaryAsset_C : USprayDataAsset {
};

