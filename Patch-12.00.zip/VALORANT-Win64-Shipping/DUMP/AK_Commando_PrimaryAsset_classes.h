// BlueprintGeneratedClass AK_Commando_PrimaryAsset.AK_Commando_PrimaryAsset_C
// Size: 0x220 (Inherited: 0x220)
struct UAK_Commando_PrimaryAsset_C : UEquippableSkinDataAsset {
};

