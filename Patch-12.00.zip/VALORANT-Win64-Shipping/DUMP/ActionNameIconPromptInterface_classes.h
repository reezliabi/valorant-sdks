// BlueprintGeneratedClass ActionNameIconPromptInterface.ActionNameIconPromptInterface_C
// Size: 0x30 (Inherited: 0x30)
struct UActionNameIconPromptInterface_C : UInterface {

	void IsInputAllowed(bool& bInputAllowed); // Function ActionNameIconPromptInterface.ActionNameIconPromptInterface_C.IsInputAllowed // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x19e0c40
};

