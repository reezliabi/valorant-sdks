// BlueprintGeneratedClass AK_Commando_Lv2_StreamedVideoDataAsset.AK_Commando_Lv2_StreamedVideoDataAsset_C
// Size: 0x90 (Inherited: 0x90)
struct UAK_Commando_Lv2_StreamedVideoDataAsset_C : UStreamedVideoDataAsset {
};

