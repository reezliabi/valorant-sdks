// BlueprintGeneratedClass AK47WeaponPurchase.AK47WeaponPurchase_C
// Size: 0xa8 (Inherited: 0xa8)
struct UAK47WeaponPurchase_C : UAresPurchasableEquippable {
};

