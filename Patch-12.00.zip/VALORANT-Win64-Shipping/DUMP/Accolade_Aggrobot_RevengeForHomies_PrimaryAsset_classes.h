// BlueprintGeneratedClass Accolade_Aggrobot_RevengeForHomies_PrimaryAsset.Accolade_Aggrobot_RevengeForHomies_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Aggrobot_RevengeForHomies_PrimaryAsset_C : UAccoladeDataAsset {
};

