// BlueprintGeneratedClass AK_Constellation_v2_PrimaryAsset.AK_Constellation_v2_PrimaryAsset_C
// Size: 0x170 (Inherited: 0x170)
struct UAK_Constellation_v2_PrimaryAsset_C : UEquippableSkinChromaDataAsset {
};

