// BlueprintGeneratedClass Ability_Thorne_Q_Heal_Production_New.Ability_Thorne_Q_Heal_Production_New_C
// Size: 0x12c8 (Inherited: 0x1242)
struct AAbility_Thorne_Q_Heal_Production_New_C : AAbility_Equipped_Base_C {
	char pad_1242[0x6]; // 0x1242(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1248(0x08)
	struct UComp_Ability_CooldownComponent_C* Comp_Ability_CooldownComponent; // 0x1250(0x08)
	struct UEquipmentChargeComponent* EquipmentCharge; // 0x1258(0x08)
	struct UApplyBuffToTargetsStateComponent* ApplyBuffToTargetsState; // 0x1260(0x08)
	struct UTestBranch_StateComponent_OwnerIsDamaged_C* TestBranch_StateComponent_OwnerIsDamaged; // 0x1268(0x08)
	struct UStateComponent_DamagedPlayerTargeting_C* StateComponent_DamagedPlayerTargeting; // 0x1270(0x08)
	struct UConsumeResourcesStateComponent* HealSelf_ConsumeResourceState; // 0x1278(0x08)
	struct UApplyBuffStateComponent* HealSelf_StateComponent; // 0x1280(0x08)
	struct UConsumeResourcesStateComponent* HealAlly_ConsumeResourcesState; // 0x1288(0x08)
	struct UAresGameplayBuff* SelfHealBuff; // 0x1290(0x08)
	struct FEffectID FXC_ID_EquippedUntilFire; // 0x1298(0x20)
	double Self Heal CD; // 0x12b8(0x08)
	double Ally Heal CD; // 0x12c0(0x08)

	void ReceiveBeginPlay(); // Function Ability_Thorne_Q_Heal_Production_New.Ability_Thorne_Q_Heal_Production_New_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__HealSelf_StateComponent_K2Node_ComponentBoundEvent_0_OnStateEnterSignature__DelegateSignature(struct UScriptStateComponent* EnteredState, struct UStateTransitionContext* StateTransitionContext, float StartTimeOffset); // Function Ability_Thorne_Q_Heal_Production_New.Ability_Thorne_Q_Heal_Production_New_C.BndEvt__HealSelf_StateComponent_K2Node_ComponentBoundEvent_0_OnStateEnterSignature__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void AuthOnEquipped(); // Function Ability_Thorne_Q_Heal_Production_New.Ability_Thorne_Q_Heal_Production_New_C.AuthOnEquipped // (BlueprintAuthorityOnly|Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void AuthOnUnEquipped(); // Function Ability_Thorne_Q_Heal_Production_New.Ability_Thorne_Q_Heal_Production_New_C.AuthOnUnEquipped // (BlueprintAuthorityOnly|Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__ApplyBuffToTargetsState_K2Node_ComponentBoundEvent_2_OnStateEnterSignature__DelegateSignature(struct UScriptStateComponent* EnteredState, struct UStateTransitionContext* StateTransitionContext, float StartTimeOffset); // Function Ability_Thorne_Q_Heal_Production_New.Ability_Thorne_Q_Heal_Production_New_C.BndEvt__ApplyBuffToTargetsState_K2Node_ComponentBoundEvent_2_OnStateEnterSignature__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_Ability_Thorne_Q_Heal_Production_New(int32_t EntryPoint); // Function Ability_Thorne_Q_Heal_Production_New.Ability_Thorne_Q_Heal_Production_New_C.ExecuteUbergraph_Ability_Thorne_Q_Heal_Production_New // (Final|UbergraphFunction|HasDefaults) // @ game+0x19e0c40
};

