// BlueprintGeneratedClass Afterglow2_LEDColorInterface.Afterglow2_LEDColorInterface_C
// Size: 0x30 (Inherited: 0x30)
struct UAfterglow2_LEDColorInterface_C : UInterface {

	void Afterglow2_SetLEDColorIndex(int32_t myNewLEDColor, int32_t& myNewLEDColorOut); // Function Afterglow2_LEDColorInterface.Afterglow2_LEDColorInterface_C.Afterglow2_SetLEDColorIndex // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void Afterglow2_DefineLEDColors(struct TArray<struct FColor>& CurrentLEDColors, struct TArray<struct FColor>& DefinedLEDColors); // Function Afterglow2_LEDColorInterface.Afterglow2_LEDColorInterface_C.Afterglow2_DefineLEDColors // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void Afterglow2_GetRandomLEDColor(struct FColor& myNewRandomLEDColor); // Function Afterglow2_LEDColorInterface.Afterglow2_LEDColorInterface_C.Afterglow2_GetRandomLEDColor // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void Afterglow2_GetLEDColor(struct TArray<struct FColor>& myLEDColors, int32_t& myCurrentLEDColor); // Function Afterglow2_LEDColorInterface.Afterglow2_LEDColorInterface_C.Afterglow2_GetLEDColor // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
};

