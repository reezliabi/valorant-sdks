// BlueprintGeneratedClass AK_Airplane_PrimaryAsset.AK_Airplane_PrimaryAsset_C
// Size: 0x220 (Inherited: 0x220)
struct UAK_Airplane_PrimaryAsset_C : UEquippableSkinDataAsset {
};

