// BlueprintGeneratedClass AK_Assault_PrimaryAsset.AK_Assault_PrimaryAsset_C
// Size: 0x220 (Inherited: 0x220)
struct UAK_Assault_PrimaryAsset_C : UEquippableSkinDataAsset {
};

