// BlueprintGeneratedClass AK_Cyberpunk2_Lv3_StreamedVideo.AK_Cyberpunk2_Lv3_StreamedVideo_C
// Size: 0x90 (Inherited: 0x90)
struct UAK_Cyberpunk2_Lv3_StreamedVideo_C : UStreamedVideoDataAsset {
};

