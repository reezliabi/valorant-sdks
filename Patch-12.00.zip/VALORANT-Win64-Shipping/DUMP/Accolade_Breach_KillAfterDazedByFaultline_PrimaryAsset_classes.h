// BlueprintGeneratedClass Accolade_Breach_KillAfterDazedByFaultline_PrimaryAsset.Accolade_Breach_KillAfterDazedByFaultline_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Breach_KillAfterDazedByFaultline_PrimaryAsset_C : UAccoladeDataAsset {
};

