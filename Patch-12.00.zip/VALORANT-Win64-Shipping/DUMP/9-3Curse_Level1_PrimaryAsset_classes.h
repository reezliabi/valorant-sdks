// BlueprintGeneratedClass 9-3Curse_Level1_PrimaryAsset.9-3Curse_Level1_PrimaryAsset_C
// Size: 0xf0 (Inherited: 0xf0)
struct U9-3Curse_Level1_PrimaryAsset_C : USprayLevelDataAsset {
};

