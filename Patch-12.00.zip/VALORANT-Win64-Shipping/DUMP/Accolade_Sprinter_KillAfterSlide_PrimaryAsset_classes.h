// BlueprintGeneratedClass Accolade_Sprinter_KillAfterSlide_PrimaryAsset.Accolade_Sprinter_KillAfterSlide_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Sprinter_KillAfterSlide_PrimaryAsset_C : UAccoladeDataAsset {
};

