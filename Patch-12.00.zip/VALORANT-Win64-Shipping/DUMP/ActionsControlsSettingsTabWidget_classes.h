// WidgetBlueprintGeneratedClass ActionsControlsSettingsTabWidget.ActionsControlsSettingsTabWidget_C
// Size: 0x328 (Inherited: 0x318)
struct UActionsControlsSettingsTabWidget_C : USettingsSubsectionWrapperBase_C {
	struct UActionControls_AbilitiesSettings_C* ActionControls_AbilitiesSettings; // 0x318(0x08)
	struct UActionControls_MovementSettings_C* ActionControls_MovementSettings; // 0x320(0x08)

	void UpdateCharacterForSettings(struct UCharacterHandle* CharacterHandle); // Function ActionsControlsSettingsTabWidget.ActionsControlsSettingsTabWidget_C.UpdateCharacterForSettings // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
};

