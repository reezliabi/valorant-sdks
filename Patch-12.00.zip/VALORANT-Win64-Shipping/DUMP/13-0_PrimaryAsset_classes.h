// BlueprintGeneratedClass 13-0_PrimaryAsset.13-0_PrimaryAsset_C
// Size: 0xd8 (Inherited: 0xd8)
struct U13-0_PrimaryAsset_C : USprayDataAsset {
};

