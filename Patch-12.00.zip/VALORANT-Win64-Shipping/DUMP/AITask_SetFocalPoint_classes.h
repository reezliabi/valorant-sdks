// BlueprintGeneratedClass AITask_SetFocalPoint.AITask_SetFocalPoint_C
// Size: 0xe8 (Inherited: 0xb0)
struct UAITask_SetFocalPoint_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb0(0x08)
	struct FBlackboardKeySelector FocalLocation; // 0xb8(0x30)

	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function AITask_SetFocalPoint.AITask_SetFocalPoint_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ReceiveAbortAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AITask_SetFocalPoint.AITask_SetFocalPoint_C.ReceiveAbortAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AITask_SetFocalPoint(int32_t EntryPoint); // Function AITask_SetFocalPoint.AITask_SetFocalPoint_C.ExecuteUbergraph_AITask_SetFocalPoint // (Final|UbergraphFunction) // @ game+0x19e0c40
};

