// BlueprintGeneratedClass ACRWeaponPurchase.ACRWeaponPurchase_C
// Size: 0xa8 (Inherited: 0xa8)
struct UACRWeaponPurchase_C : UAresPurchasableEquippable {
};

