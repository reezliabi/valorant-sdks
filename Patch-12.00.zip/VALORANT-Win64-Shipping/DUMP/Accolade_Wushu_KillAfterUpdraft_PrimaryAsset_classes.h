// BlueprintGeneratedClass Accolade_Wushu_KillAfterUpdraft_PrimaryAsset.Accolade_Wushu_KillAfterUpdraft_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Wushu_KillAfterUpdraft_PrimaryAsset_C : UAccoladeDataAsset {
};

