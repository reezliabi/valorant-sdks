// BlueprintGeneratedClass AIServie_LookAtFocalPoint.AIServie_LookAtFocalPoint_C
// Size: 0xd8 (Inherited: 0xa0)
struct UAIServie_LookAtFocalPoint_C : UBTService_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa0(0x08)
	struct FBlackboardKeySelector FocusObject; // 0xa8(0x30)

	void ReceiveDeactivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIServie_LookAtFocalPoint.AIServie_LookAtFocalPoint_C.ReceiveDeactivationAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function AIServie_LookAtFocalPoint.AIServie_LookAtFocalPoint_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AIServie_LookAtFocalPoint(int32_t EntryPoint); // Function AIServie_LookAtFocalPoint.AIServie_LookAtFocalPoint_C.ExecuteUbergraph_AIServie_LookAtFocalPoint // (Final|UbergraphFunction) // @ game+0x19e0c40
};

