// BlueprintGeneratedClass AK_Champions2023_Level03_StreamedVideoDataAsset.AK_Champions2023_Level03_StreamedVideoDataAsset_C
// Size: 0x90 (Inherited: 0x90)
struct UAK_Champions2023_Level03_StreamedVideoDataAsset_C : UStreamedVideoDataAsset {
};

