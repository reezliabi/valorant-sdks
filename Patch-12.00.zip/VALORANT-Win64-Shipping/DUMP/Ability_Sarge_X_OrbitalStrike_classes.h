// BlueprintGeneratedClass Ability_Sarge_X_OrbitalStrike.Ability_Sarge_X_OrbitalStrike_C
// Size: 0x1280 (Inherited: 0x1242)
struct AAbility_Sarge_X_OrbitalStrike_C : AAbility_Equipped_Base_C {
	char pad_1242[0x6]; // 0x1242(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1248(0x08)
	struct UMapTargetingStateComponent* MapTargetingState; // 0x1250(0x08)
	struct UUltimateVOComponent_C* AbilityVOComponent; // 0x1258(0x08)
	struct UEquippableVisibilityComponent* EquippableVisibility; // 0x1260(0x08)
	struct UConsumeResourcesStateComponent* ConsumeResourcesState; // 0x1268(0x08)
	struct UUltPointsComponent* UltPoints; // 0x1270(0x08)
	struct USpawnActorStateComponent* SpawnAirStrike; // 0x1278(0x08)

	void ReceiveBeginPlay(); // Function Ability_Sarge_X_OrbitalStrike.Ability_Sarge_X_OrbitalStrike_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__EquippableVisibility_K2Node_ComponentBoundEvent_4_CanBeSeenByCharacterOverride__DelegateSignature(struct UVisibilityComponent* VisibilityComponent, struct AShooterCharacter* Character); // Function Ability_Sarge_X_OrbitalStrike.Ability_Sarge_X_OrbitalStrike_C.BndEvt__EquippableVisibility_K2Node_ComponentBoundEvent_4_CanBeSeenByCharacterOverride__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void ClientItemUnEquipped(); // Function Ability_Sarge_X_OrbitalStrike.Ability_Sarge_X_OrbitalStrike_C.ClientItemUnEquipped // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x19e0c40
	void ClientItemEquipped(); // Function Ability_Sarge_X_OrbitalStrike.Ability_Sarge_X_OrbitalStrike_C.ClientItemEquipped // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__SpawnAirStrike_K2Node_ComponentBoundEvent_0_OnStateEnterSignature__DelegateSignature(struct UScriptStateComponent* EnteredState, struct UStateTransitionContext* StateTransitionContext, float StartTimeOffset); // Function Ability_Sarge_X_OrbitalStrike.Ability_Sarge_X_OrbitalStrike_C.BndEvt__SpawnAirStrike_K2Node_ComponentBoundEvent_0_OnStateEnterSignature__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_Ability_Sarge_X_OrbitalStrike(int32_t EntryPoint); // Function Ability_Sarge_X_OrbitalStrike.Ability_Sarge_X_OrbitalStrike_C.ExecuteUbergraph_Ability_Sarge_X_OrbitalStrike // (Final|UbergraphFunction|HasDefaults) // @ game+0x19e0c40
};

