// BlueprintGeneratedClass AK_Commando_Lv3_StreamedVideoDataAsset.AK_Commando_Lv3_StreamedVideoDataAsset_C
// Size: 0x90 (Inherited: 0x90)
struct UAK_Commando_Lv3_StreamedVideoDataAsset_C : UStreamedVideoDataAsset {
};

