// BlueprintGeneratedClass AK_Brigade_PrimaryAsset.AK_Brigade_PrimaryAsset_C
// Size: 0x220 (Inherited: 0x220)
struct UAK_Brigade_PrimaryAsset_C : UEquippableSkinDataAsset {
};

