// BlueprintGeneratedClass AIAimComp_PlayerCharacterOffset.AIAimComp_PlayerCharacterOffset_C
// Size: 0xfc (Inherited: 0xd8)
struct UAIAimComp_PlayerCharacterOffset_C : UActorComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd8(0x08)
	enum class EAIAimPlayerCharacterOffset OffsetType; // 0xe0(0x01)
	char pad_E1[0x7]; // 0xe1(0x07)
	double BodyCapsuleHeightOffset; // 0xe8(0x08)
	struct UAresBotDebugComponent* DebugComponent; // 0xf0(0x08)
	int32_t DebugAimOffsetSphereId; // 0xf8(0x04)

	void ApproxLegLocation(struct ABasePlayerCharacter_C* PlayerCharacter, struct FVector& Location); // Function AIAimComp_PlayerCharacterOffset.AIAimComp_PlayerCharacterOffset_C.ApproxLegLocation // (Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x19e0c40
	void ApproxHeadLocation(struct ABasePlayerCharacter_C* PlayerCharacter, struct FVector& Location); // Function AIAimComp_PlayerCharacterOffset.AIAimComp_PlayerCharacterOffset_C.ApproxHeadLocation // (Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x19e0c40
	void ApproxBodyLocation(struct ABasePlayerCharacter_C* PlayerCharacter, struct FVector& Location); // Function AIAimComp_PlayerCharacterOffset.AIAimComp_PlayerCharacterOffset_C.ApproxBodyLocation // (Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x19e0c40
	void DrawDebugVis(struct FVector Location); // Function AIAimComp_PlayerCharacterOffset.AIAimComp_PlayerCharacterOffset_C.DrawDebugVis // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void GetOffsetLocationForActor(struct AActor* FocusActor, struct FVector& OffsetLocation); // Function AIAimComp_PlayerCharacterOffset.AIAimComp_PlayerCharacterOffset_C.GetOffsetLocationForActor // (Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void GetAimOffsetLocation(struct AActor* FocusActor, struct FVector FocusLocation, struct FVector& OffsetLocation); // Function AIAimComp_PlayerCharacterOffset.AIAimComp_PlayerCharacterOffset_C.GetAimOffsetLocation // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void ReceiveBeginPlay(); // Function AIAimComp_PlayerCharacterOffset.AIAimComp_PlayerCharacterOffset_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AIAimComp_PlayerCharacterOffset(int32_t EntryPoint); // Function AIAimComp_PlayerCharacterOffset.AIAimComp_PlayerCharacterOffset_C.ExecuteUbergraph_AIAimComp_PlayerCharacterOffset // (Final|UbergraphFunction) // @ game+0x19e0c40
};

