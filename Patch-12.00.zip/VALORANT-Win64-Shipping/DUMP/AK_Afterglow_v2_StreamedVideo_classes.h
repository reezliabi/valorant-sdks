// BlueprintGeneratedClass AK_Afterglow_v2_StreamedVideo.AK_Afterglow_v2_StreamedVideo_C
// Size: 0x90 (Inherited: 0x90)
struct UAK_Afterglow_v2_StreamedVideo_C : UAK_Afterglow_Lv1_StreamedVideo_C {
};

