// BlueprintGeneratedClass Afterglow_PrimaryAsset.Afterglow_PrimaryAsset_C
// Size: 0xd8 (Inherited: 0xd8)
struct UAfterglow_PrimaryAsset_C : USprayDataAsset {
};

