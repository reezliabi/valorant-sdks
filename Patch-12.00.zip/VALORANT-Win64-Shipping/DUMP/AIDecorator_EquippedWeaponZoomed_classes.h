// BlueprintGeneratedClass AIDecorator_EquippedWeaponZoomed.AIDecorator_EquippedWeaponZoomed_C
// Size: 0xa8 (Inherited: 0xa8)
struct UAIDecorator_EquippedWeaponZoomed_C : UBTDecorator_BlueprintBase {

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIDecorator_EquippedWeaponZoomed.AIDecorator_EquippedWeaponZoomed_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
};

