// BlueprintGeneratedClass Accolade_Pandemic_KillInsideUltAfterSpikePlant_PrimaryAsset.Accolade_Pandemic_KillInsideUltAfterSpikePlant_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Pandemic_KillInsideUltAfterSpikePlant_PrimaryAsset_C : UAccoladeDataAsset {
};

