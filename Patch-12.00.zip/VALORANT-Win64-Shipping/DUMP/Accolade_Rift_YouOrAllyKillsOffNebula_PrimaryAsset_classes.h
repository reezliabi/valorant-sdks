// BlueprintGeneratedClass Accolade_Rift_YouOrAllyKillsOffNebula_PrimaryAsset.Accolade_Rift_YouOrAllyKillsOffNebula_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Rift_YouOrAllyKillsOffNebula_PrimaryAsset_C : UAccoladeDataAsset {
};

