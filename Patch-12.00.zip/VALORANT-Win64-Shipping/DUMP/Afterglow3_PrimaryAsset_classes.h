// BlueprintGeneratedClass Afterglow3_PrimaryAsset.Afterglow3_PrimaryAsset_C
// Size: 0xd8 (Inherited: 0xd8)
struct UAfterglow3_PrimaryAsset_C : USprayDataAsset {
};

