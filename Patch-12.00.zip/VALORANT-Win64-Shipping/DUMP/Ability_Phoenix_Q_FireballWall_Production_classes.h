// BlueprintGeneratedClass Ability_Phoenix_Q_FireballWall_Production.Ability_Phoenix_Q_FireballWall_Production_C
// Size: 0x12b8 (Inherited: 0x1242)
struct AAbility_Phoenix_Q_FireballWall_Production_C : AAbility_Equipped_Base_C {
	char pad_1242[0x6]; // 0x1242(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1248(0x08)
	struct UConsumeResourcesStateComponent* ConsumeResourceSwipeLeftState; // 0x1250(0x08)
	struct UConsumeResourcesStateComponent* ConsumeResourceSwipeRightState; // 0x1258(0x08)
	struct UProjectileBending_StateComponent_C* BendingUpSwipeState; // 0x1260(0x08)
	struct UConsumeResourcesStateComponent* ConsumeResourceUpSwipeState; // 0x1268(0x08)
	struct UDestroyContextActors_StateComponent_C* DestroyContextActors_StateComponent; // 0x1270(0x08)
	struct UProjectileBendingThrow_StateComponent_C* UpProjectileBendingThrowState; // 0x1278(0x08)
	struct UProjectileBendingThrow_StateComponent_C* RightProjectileBendingThrowState; // 0x1280(0x08)
	struct UProjectileBendingThrow_StateComponent_C* LeftProjectileBendingThrowState; // 0x1288(0x08)
	struct UEquipmentChargeComponent* EquipmentCharge; // 0x1290(0x08)
	struct UProjectileBending_StateComponent_C* BendingState; // 0x1298(0x08)
	struct UConsumeResourcesStateComponent* ConsumeResourcesState; // 0x12a0(0x08)
	struct UProjectileThrowStateComponent* ProjectileThrowState; // 0x12a8(0x08)
	struct URespondToEventStateComponent* RespondToEventState_ThrowProjectile; // 0x12b0(0x08)

	void SetupStateMachine(); // Function Ability_Phoenix_Q_FireballWall_Production.Ability_Phoenix_Q_FireballWall_Production_C.SetupStateMachine // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void SetupSwipeUpStates(); // Function Ability_Phoenix_Q_FireballWall_Production.Ability_Phoenix_Q_FireballWall_Production_C.SetupSwipeUpStates // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void SetupSwipeRightStates(); // Function Ability_Phoenix_Q_FireballWall_Production.Ability_Phoenix_Q_FireballWall_Production_C.SetupSwipeRightStates // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void SetupSwipeLeftStates(); // Function Ability_Phoenix_Q_FireballWall_Production.Ability_Phoenix_Q_FireballWall_Production_C.SetupSwipeLeftStates // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	struct UBaseCrosshairHudElement* GetCurrentCrosshairHudElementClass(); // Function Ability_Phoenix_Q_FireballWall_Production.Ability_Phoenix_Q_FireballWall_Production_C.GetCurrentCrosshairHudElementClass // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x19e0c40
	void ReceiveBeginPlay(); // Function Ability_Phoenix_Q_FireballWall_Production.Ability_Phoenix_Q_FireballWall_Production_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__ProjectileThrowState_K2Node_ComponentBoundEvent_0_OnStateExitSignature__DelegateSignature(struct UScriptStateComponent* ExitedState, struct UStateTransitionContext* StateTransitionContext); // Function Ability_Phoenix_Q_FireballWall_Production.Ability_Phoenix_Q_FireballWall_Production_C.BndEvt__ProjectileThrowState_K2Node_ComponentBoundEvent_0_OnStateExitSignature__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_Ability_Phoenix_Q_FireballWall_Production(int32_t EntryPoint); // Function Ability_Phoenix_Q_FireballWall_Production.Ability_Phoenix_Q_FireballWall_Production_C.ExecuteUbergraph_Ability_Phoenix_Q_FireballWall_Production // (Final|UbergraphFunction) // @ game+0x19e0c40
};

