// BlueprintGeneratedClass 8BitTactisloth_PrimaryAsset.8BitTactisloth_PrimaryAsset_C
// Size: 0xd8 (Inherited: 0xd8)
struct U8BitTactisloth_PrimaryAsset_C : USprayDataAsset {
};

