// BlueprintGeneratedClass AIService_FocusOnPerceivedTarget.AIService_FocusOnPerceivedTarget_C
// Size: 0x108 (Inherited: 0xa0)
struct UAIService_FocusOnPerceivedTarget_C : UBTService_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa0(0x08)
	struct FBlackboardKeySelector FocusObject; // 0xa8(0x30)
	struct FBlackboardKeySelector FallBackLocation; // 0xd8(0x30)

	void ReceiveDeactivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIService_FocusOnPerceivedTarget.AIService_FocusOnPerceivedTarget_C.ReceiveDeactivationAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function AIService_FocusOnPerceivedTarget.AIService_FocusOnPerceivedTarget_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ReceiveActivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIService_FocusOnPerceivedTarget.AIService_FocusOnPerceivedTarget_C.ReceiveActivationAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void SetFocus(struct AAIController* Controller); // Function AIService_FocusOnPerceivedTarget.AIService_FocusOnPerceivedTarget_C.SetFocus // (BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AIService_FocusOnPerceivedTarget(int32_t EntryPoint); // Function AIService_FocusOnPerceivedTarget.AIService_FocusOnPerceivedTarget_C.ExecuteUbergraph_AIService_FocusOnPerceivedTarget // (Final|UbergraphFunction) // @ game+0x19e0c40
};

