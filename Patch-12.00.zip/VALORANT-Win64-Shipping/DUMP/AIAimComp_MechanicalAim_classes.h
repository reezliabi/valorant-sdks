// BlueprintGeneratedClass AIAimComp_MechanicalAim.AIAimComp_MechanicalAim_C
// Size: 0x208 (Inherited: 0xd8)
struct UAIAimComp_MechanicalAim_C : UActorComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd8(0x08)
	struct AAIController* OwningController; // 0xe0(0x08)
	struct FVector TargetRotation; // 0xe8(0x18)
	struct FVector DesiredRotation; // 0x100(0x18)
	struct FVector CurrentRotation; // 0x118(0x18)
	int32_t TargetRotatorLineId; // 0x130(0x04)
	int32_t TargetRotatorSphereId; // 0x134(0x04)
	int32_t FlickDestinationLineId; // 0x138(0x04)
	int32_t FlickDestinationSphereId; // 0x13c(0x04)
	struct UAresBotDebugComponent* DebugComponent; // 0x140(0x08)
	bool bValidTargetRotation; // 0x148(0x01)
	char pad_149[0x7]; // 0x149(0x07)
	double FlickAngleErrorStd; // 0x150(0x08)
	double FlickAngleErrorMax; // 0x158(0x08)
	struct FTimerHandle FlickCompleteDelayTimer; // 0x160(0x08)
	struct UCurveFloat* FlickAngleByDistanceErrorStd; // 0x168(0x08)
	struct UCurveFloat* FlickDurationByFlickDistance; // 0x170(0x08)
	double FlickDistanceErrorMax; // 0x178(0x08)
	double PostFlickDelay; // 0x180(0x08)
	bool bFlicking; // 0x188(0x01)
	char pad_189[0x7]; // 0x189(0x07)
	double PostFlickDelayStd; // 0x190(0x08)
	double SmoothAdjustAngle; // 0x198(0x08)
	double CurrentDeltaTime; // 0x1a0(0x08)
	struct UCurveFloat* SmoothAdjustTargetSpeedCurve; // 0x1a8(0x08)
	bool bValidPredictions; // 0x1b0(0x01)
	char pad_1B1[0x7]; // 0x1b1(0x07)
	struct FVector InterpRotation; // 0x1b8(0x18)
	struct FVector FlickOriginRotation; // 0x1d0(0x18)
	double FlickStartTime; // 0x1e8(0x08)
	double FlickDuration; // 0x1f0(0x08)
	double RelativeMovementCompensationFactor; // 0x1f8(0x08)
	double FlickDurationMultiplier; // 0x200(0x08)

	void AdjustInterpRotationForSmoothAdjust(struct FVector PredictedTargetLocation, struct FVector PredictedTargetVelocity); // Function AIAimComp_MechanicalAim.AIAimComp_MechanicalAim_C.AdjustInterpRotationForSmoothAdjust // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void SamplePostFlickDelay(double& PostFlickDelay); // Function AIAimComp_MechanicalAim.AIAimComp_MechanicalAim_C.SamplePostFlickDelay // (Private|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x19e0c40
	void SampleFlickDistanceError(double BaseDistance, double& DistanceError); // Function AIAimComp_MechanicalAim.AIAimComp_MechanicalAim_C.SampleFlickDistanceError // (Private|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x19e0c40
	void SampleFlickAngleError(double& FlickAngleError); // Function AIAimComp_MechanicalAim.AIAimComp_MechanicalAim_C.SampleFlickAngleError // (Private|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x19e0c40
	void ClampPitchTo90(struct FVector In, struct FVector& Out); // Function AIAimComp_MechanicalAim.AIAimComp_MechanicalAim_C.ClampPitchTo90 // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x19e0c40
	void SampleNormal2Std(double Std, double& output); // Function AIAimComp_MechanicalAim.AIAimComp_MechanicalAim_C.SampleNormal2Std // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x19e0c40
	void DrawDebug(); // Function AIAimComp_MechanicalAim.AIAimComp_MechanicalAim_C.DrawDebug // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void AdjustFlickTargetForRelativeMovement(struct FVector PredictedTargetLocation, struct FVector PredictedTargetVelocity); // Function AIAimComp_MechanicalAim.AIAimComp_MechanicalAim_C.AdjustFlickTargetForRelativeMovement // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void CompleteFlick(); // Function AIAimComp_MechanicalAim.AIAimComp_MechanicalAim_C.CompleteFlick // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void SetDelayOnFlickComplete(); // Function AIAimComp_MechanicalAim.AIAimComp_MechanicalAim_C.SetDelayOnFlickComplete // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void ShouldFlick(bool& ShouldFlick); // Function AIAimComp_MechanicalAim.AIAimComp_MechanicalAim_C.ShouldFlick // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x19e0c40
	void MechanicalInterpTowardsTarget(); // Function AIAimComp_MechanicalAim.AIAimComp_MechanicalAim_C.MechanicalInterpTowardsTarget // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void SetFlickRotation(); // Function AIAimComp_MechanicalAim.AIAimComp_MechanicalAim_C.SetFlickRotation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void SetTargetRotation(); // Function AIAimComp_MechanicalAim.AIAimComp_MechanicalAim_C.SetTargetRotation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void InitializeTargetRotation(); // Function AIAimComp_MechanicalAim.AIAimComp_MechanicalAim_C.InitializeTargetRotation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void CompensateForMechanical Aim(struct FRotator DesiredRotator, struct FVector PredictedTargetLocation, struct FVector PredictedTargetVelocity, double DeltaTime, bool bInValidPredictions, struct FRotator& OutRotator); // Function AIAimComp_MechanicalAim.AIAimComp_MechanicalAim_C.CompensateForMechanical Aim // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void ReceiveBeginPlay(); // Function AIAimComp_MechanicalAim.AIAimComp_MechanicalAim_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AIAimComp_MechanicalAim(int32_t EntryPoint); // Function AIAimComp_MechanicalAim.AIAimComp_MechanicalAim_C.ExecuteUbergraph_AIAimComp_MechanicalAim // (Final|UbergraphFunction) // @ game+0x19e0c40
};

