// BlueprintGeneratedClass AITask_zoomEquippedWeapon.AITask_ZoomEquippedWeapon_C
// Size: 0xb8 (Inherited: 0xb0)
struct UAITask_ZoomEquippedWeapon_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb0(0x08)

	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function AITask_zoomEquippedWeapon.AITask_ZoomEquippedWeapon_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AITask_ZoomEquippedWeapon(int32_t EntryPoint); // Function AITask_zoomEquippedWeapon.AITask_ZoomEquippedWeapon_C.ExecuteUbergraph_AITask_ZoomEquippedWeapon // (Final|UbergraphFunction) // @ game+0x19e0c40
};

