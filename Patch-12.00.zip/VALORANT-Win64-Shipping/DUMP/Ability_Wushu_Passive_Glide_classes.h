// BlueprintGeneratedClass Ability_Wushu_Passive_Glide.Ability_Wushu_Passive_Glide_C
// Size: 0x1190 (Inherited: 0x10e0)
struct AAbility_Wushu_Passive_Glide_C : AAresEquippable {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x10e0(0x08)
	struct UApplyForceModuleStateComponent* ApplyForceModuleState; // 0x10e8(0x08)
	struct AEffectContainer* GlideFXC; // 0x10f0(0x08)
	struct FEffectID GlideFXCHandle; // 0x10f8(0x20)
	double LastActivationTime; // 0x1118(0x08)
	double StartIntensityMaxTime; // 0x1120(0x08)
	double LastDeactivationTime; // 0x1128(0x08)
	bool IsActive; // 0x1130(0x01)
	char pad_1131[0x7]; // 0x1131(0x07)
	double LandTimeAllowance; // 0x1138(0x08)
	double LandIntensityMaxTime; // 0x1140(0x08)
	struct FName ContinuousNoiseLabel; // 0x1148(0x0c)
	char pad_1154[0x4]; // 0x1154(0x04)
	struct FNoiseEventData NoiseEvent; // 0x1158(0x38)

	void PlayLandingEffectContainer(); // Function Ability_Wushu_Passive_Glide.Ability_Wushu_Passive_Glide_C.PlayLandingEffectContainer // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	struct FEffectID StartEffectContainer(); // Function Ability_Wushu_Passive_Glide.Ability_Wushu_Passive_Glide_C.StartEffectContainer // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void ReceiveBeginPlay(); // Function Ability_Wushu_Passive_Glide.Ability_Wushu_Passive_Glide_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void StartGliding(); // Function Ability_Wushu_Passive_Glide.Ability_Wushu_Passive_Glide_C.StartGliding // (BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void StopGliding(); // Function Ability_Wushu_Passive_Glide.Ability_Wushu_Passive_Glide_C.StopGliding // (BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void ItemOnSetOwner_Event_1(struct AAresItem* Item, struct AActor* PrevOwner, struct AActor* NewOwner); // Function Ability_Wushu_Passive_Glide.Ability_Wushu_Passive_Glide_C.ItemOnSetOwner_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void MovementModeChanged(struct ACharacter* Character, enum class EMovementMode PrevMovementMode, char PreviousCustomMode); // Function Ability_Wushu_Passive_Glide.Ability_Wushu_Passive_Glide_C.MovementModeChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void SetVisualsActive(bool Active); // Function Ability_Wushu_Passive_Glide.Ability_Wushu_Passive_Glide_C.SetVisualsActive // (BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void OnCharacterLanded_Event_1(struct AShooterCharacter* Character, struct FHitResult HitResult); // Function Ability_Wushu_Passive_Glide.Ability_Wushu_Passive_Glide_C.OnCharacterLanded_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_Ability_Wushu_Passive_Glide(int32_t EntryPoint); // Function Ability_Wushu_Passive_Glide.Ability_Wushu_Passive_Glide_C.ExecuteUbergraph_Ability_Wushu_Passive_Glide // (Final|UbergraphFunction|HasDefaults) // @ game+0x19e0c40
};

