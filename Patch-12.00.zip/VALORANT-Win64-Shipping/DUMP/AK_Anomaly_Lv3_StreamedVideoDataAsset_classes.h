// BlueprintGeneratedClass AK_Anomaly_Lv3_StreamedVideoDataAsset.AK_Anomaly_Lv3_StreamedVideoDataAsset_C
// Size: 0x90 (Inherited: 0x90)
struct UAK_Anomaly_Lv3_StreamedVideoDataAsset_C : UStreamedVideoDataAsset {
};

