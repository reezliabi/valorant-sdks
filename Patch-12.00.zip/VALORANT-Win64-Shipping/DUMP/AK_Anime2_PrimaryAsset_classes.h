// BlueprintGeneratedClass AK_Anime2_PrimaryAsset.AK_Anime2_PrimaryAsset_C
// Size: 0x220 (Inherited: 0x220)
struct UAK_Anime2_PrimaryAsset_C : UEquippableSkinDataAsset {
};

