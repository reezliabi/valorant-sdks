// BlueprintGeneratedClass AIDebugObserverController.AIDebugObserverController_C
// Size: 0xe30 (Inherited: 0xe1c)
struct AAIDebugObserverController_C : ABaseObserverController_C {
	char pad_E1C[0x4]; // 0xe1c(0x04)
	struct UAresBotDebugPlayerComponent* AresBotDebugPlayerComponent; // 0xe20(0x08)
	struct UAISpatialAwarenessDebugControllerComponent* AISpatialAwarenessDebugControllerComponent; // 0xe28(0x08)
};

