// WidgetBlueprintGeneratedClass AbilityCastsReportWidget_DesktopV2.AbilityCastsReportWidget_DesktopV2_C
// Size: 0x478 (Inherited: 0x468)
struct UAbilityCastsReportWidget_DesktopV2_C : UAbilityCastsReportWidget_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x468(0x08)
	struct UWidgetAnimation* Hourglass_Loop; // 0x470(0x08)

	void CreateSingleCastWidget(struct APlayerController* OwningPlayer, struct USingleAbilityCastReportWidget_C*& Created); // Function AbilityCastsReportWidget_DesktopV2.AbilityCastsReportWidget_DesktopV2_C.CreateSingleCastWidget // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void Construct(); // Function AbilityCastsReportWidget_DesktopV2.AbilityCastsReportWidget_DesktopV2_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AbilityCastsReportWidget_DesktopV2(int32_t EntryPoint); // Function AbilityCastsReportWidget_DesktopV2.AbilityCastsReportWidget_DesktopV2_C.ExecuteUbergraph_AbilityCastsReportWidget_DesktopV2 // (Final|UbergraphFunction) // @ game+0x19e0c40
};

