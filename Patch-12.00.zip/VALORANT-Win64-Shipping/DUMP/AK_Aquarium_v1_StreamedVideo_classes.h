// BlueprintGeneratedClass AK_Aquarium_v1_StreamedVideo.AK_Aquarium_v1_StreamedVideo_C
// Size: 0x90 (Inherited: 0x90)
struct UAK_Aquarium_v1_StreamedVideo_C : UStreamedVideoDataAsset {
};

