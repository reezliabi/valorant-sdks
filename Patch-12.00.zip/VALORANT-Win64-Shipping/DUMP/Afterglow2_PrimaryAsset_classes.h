// BlueprintGeneratedClass Afterglow2_PrimaryAsset.Afterglow2_PrimaryAsset_C
// Size: 0xd8 (Inherited: 0xd8)
struct UAfterglow2_PrimaryAsset_C : USprayDataAsset {
};

