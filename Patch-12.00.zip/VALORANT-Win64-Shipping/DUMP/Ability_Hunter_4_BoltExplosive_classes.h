// BlueprintGeneratedClass Ability_Hunter_4_BoltExplosive.Ability_Hunter_4_BoltExplosive_C
// Size: 0x1388 (Inherited: 0x1379)
struct AAbility_Hunter_4_BoltExplosive_C : AAbility_Hunter_BoltParent_C {
	char pad_1379[0x7]; // 0x1379(0x07)
	struct UEquipmentChargeComponent* EquipmentCharge; // 0x1380(0x08)
};

