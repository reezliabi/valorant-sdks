// BlueprintGeneratedClass AK_Circle_v2_PrimaryAsset.AK_Circle_v2_PrimaryAsset_C
// Size: 0x170 (Inherited: 0x170)
struct UAK_Circle_v2_PrimaryAsset_C : UEquippableSkinChromaDataAsset {
};

