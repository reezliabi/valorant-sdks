// BlueprintGeneratedClass Accolade_Breach_KillAfterAftershockPrimaryAsset.Accolade_Breach_KillAfterAftershockPrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Breach_KillAfterAftershockPrimaryAsset_C : UAccoladeDataAsset {
};

