// BlueprintGeneratedClass Accolade_Smonk_KillOrAssistDuringHeal_PrimaryAsset.Accolade_Smonk_KillOrAssistDuringHeal_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Smonk_KillOrAssistDuringHeal_PrimaryAsset_C : UAccoladeDataAsset {
};

