// BlueprintGeneratedClass AggroBot_PrimaryAsset.AggroBot_PrimaryAsset_C
// Size: 0x1d1 (Inherited: 0x1d1)
struct UAggroBot_PrimaryAsset_C : UBaseCharacterPrimaryDataAsset_C {
};

