// BlueprintGeneratedClass Act2Spicy_PrimaryAsset.Act2Spicy_PrimaryAsset_C
// Size: 0xd8 (Inherited: 0xd8)
struct UAct2Spicy_PrimaryAsset_C : USprayDataAsset {
};

