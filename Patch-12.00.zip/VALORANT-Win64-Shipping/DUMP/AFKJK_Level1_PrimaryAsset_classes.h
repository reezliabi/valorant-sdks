// BlueprintGeneratedClass AFKJK_Level1_PrimaryAsset.AFKJK_Level1_PrimaryAsset_C
// Size: 0xf0 (Inherited: 0xf0)
struct UAFKJK_Level1_PrimaryAsset_C : USprayLevelDataAsset {
};

