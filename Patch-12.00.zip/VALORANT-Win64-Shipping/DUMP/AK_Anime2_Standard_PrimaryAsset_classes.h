// BlueprintGeneratedClass AK_Anime2_Standard_PrimaryAsset.AK_Anime2_Standard_PrimaryAsset_C
// Size: 0x170 (Inherited: 0x170)
struct UAK_Anime2_Standard_PrimaryAsset_C : UEquippableSkinChromaDataAsset {
};

