// BlueprintGeneratedClass Accolade_Aggrobot_KillAfterThrashDetain_PrimaryAsset.Accolade_Aggrobot_KillAfterThrashDetain_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Aggrobot_KillAfterThrashDetain_PrimaryAsset_C : UAccoladeDataAsset {
};

