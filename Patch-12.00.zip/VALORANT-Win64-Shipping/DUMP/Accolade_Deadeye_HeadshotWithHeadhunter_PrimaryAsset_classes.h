// BlueprintGeneratedClass Accolade_Deadeye_HeadshotWithHeadhunter_PrimaryAsset.Accolade_Deadeye_HeadshotWithHeadhunter_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Deadeye_HeadshotWithHeadhunter_PrimaryAsset_C : UAccoladeDataAsset {
};

