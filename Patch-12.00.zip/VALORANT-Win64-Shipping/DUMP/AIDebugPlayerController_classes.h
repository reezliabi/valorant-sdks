// BlueprintGeneratedClass AIDebugPlayerController.AIDebugPlayerController_C
// Size: 0x10d0 (Inherited: 0x10b0)
struct AAIDebugPlayerController_C : ABaseController_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x10b0(0x08)
	struct UBTMPlayerAssistantComponent_C* BTMPlayerAssistantComponent; // 0x10b8(0x08)
	struct UAresBotDebugPlayerComponent* AresBotDebugPlayerComponent; // 0x10c0(0x08)
	struct UAISpatialAwarenessDebugControllerComponent* AISpatialAwarenessDebugControllerComponent; // 0x10c8(0x08)

	void ReceiveBeginPlay(); // Function AIDebugPlayerController.AIDebugPlayerController_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AIDebugPlayerController(int32_t EntryPoint); // Function AIDebugPlayerController.AIDebugPlayerController_C.ExecuteUbergraph_AIDebugPlayerController // (Final|UbergraphFunction) // @ game+0x19e0c40
};

