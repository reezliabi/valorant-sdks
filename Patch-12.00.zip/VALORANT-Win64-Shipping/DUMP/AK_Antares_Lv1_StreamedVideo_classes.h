// BlueprintGeneratedClass AK_Antares_Lv1_StreamedVideo.AK_Antares_Lv1_StreamedVideo_C
// Size: 0x90 (Inherited: 0x90)
struct UAK_Antares_Lv1_StreamedVideo_C : UStreamedVideoDataAsset {
};

