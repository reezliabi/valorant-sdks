// BlueprintGeneratedClass AbilityUsageObjective_PrimaryAsset.AbilityUsageObjective_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAbilityUsageObjective_PrimaryAsset_C : UObjectiveDataAsset {
};

