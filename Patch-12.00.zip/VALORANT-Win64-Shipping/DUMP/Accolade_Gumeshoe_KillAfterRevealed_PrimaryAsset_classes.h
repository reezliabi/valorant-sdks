// BlueprintGeneratedClass Accolade_Gumeshoe_KillAfterRevealed_PrimaryAsset.Accolade_Gumeshoe_KillAfterRevealed_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Gumeshoe_KillAfterRevealed_PrimaryAsset_C : UAccoladeDataAsset {
};

