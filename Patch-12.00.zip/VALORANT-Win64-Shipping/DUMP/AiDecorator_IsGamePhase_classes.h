// BlueprintGeneratedClass AiDecorator_IsGamePhase.AiDecorator_IsGamePhase_C
// Size: 0xa9 (Inherited: 0xa8)
struct UAiDecorator_IsGamePhase_C : UBTDecorator_BlueprintBase {
	enum class EAresGamePhase GamePhase; // 0xa8(0x01)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AiDecorator_IsGamePhase.AiDecorator_IsGamePhase_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
};

