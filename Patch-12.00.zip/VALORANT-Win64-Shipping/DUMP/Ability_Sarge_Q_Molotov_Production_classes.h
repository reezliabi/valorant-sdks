// BlueprintGeneratedClass Ability_Sarge_Q_Molotov_Production.Ability_Sarge_Q_Molotov_Production_C
// Size: 0x1278 (Inherited: 0x1242)
struct AAbility_Sarge_Q_Molotov_Production_C : AAbility_Equipped_Base_C {
	char pad_1242[0x6]; // 0x1242(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1248(0x08)
	struct UConsumeResourcesStateComponent* ConsumeResourcesState; // 0x1250(0x08)
	struct UProjectileThrowStateComponent* ProjectileThrowState; // 0x1258(0x08)
	struct UCrosshairComponent* Crosshair; // 0x1260(0x08)
	struct UEquipmentChargeComponent* EquipmentCharge; // 0x1268(0x08)
	struct URespondToEventStateComponent* RespondToEventState_1; // 0x1270(0x08)

	void ReceiveBeginPlay(); // Function Ability_Sarge_Q_Molotov_Production.Ability_Sarge_Q_Molotov_Production_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_Ability_Sarge_Q_Molotov_Production(int32_t EntryPoint); // Function Ability_Sarge_Q_Molotov_Production.Ability_Sarge_Q_Molotov_Production_C.ExecuteUbergraph_Ability_Sarge_Q_Molotov_Production // (Final|UbergraphFunction|HasDefaults) // @ game+0x19e0c40
};

