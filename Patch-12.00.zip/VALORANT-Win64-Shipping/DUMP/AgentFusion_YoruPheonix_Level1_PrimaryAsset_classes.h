// BlueprintGeneratedClass AgentFusion_YoruPheonix_Level1_PrimaryAsset.AgentFusion_YoruPheonix_Level1_PrimaryAsset_C
// Size: 0xf0 (Inherited: 0xf0)
struct UAgentFusion_YoruPheonix_Level1_PrimaryAsset_C : USprayLevelDataAsset {
};

