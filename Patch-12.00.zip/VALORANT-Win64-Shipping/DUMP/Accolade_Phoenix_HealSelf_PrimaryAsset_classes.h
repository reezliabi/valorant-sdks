// BlueprintGeneratedClass Accolade_Phoenix_HealSelf_PrimaryAsset.Accolade_Phoenix_HealSelf_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Phoenix_HealSelf_PrimaryAsset_C : UAccoladeDataAsset {
};

