// BlueprintGeneratedClass AI_Function_Library.AI_Function_Library_C
// Size: 0x30 (Inherited: 0x30)
struct UAI_Function_Library_C : UBlueprintFunctionLibrary {

	void IsValidNavPath(struct UNavigationPath* NavPath, struct UObject* __WorldContext, bool& IsValid); // Function AI_Function_Library.AI_Function_Library_C.IsValidNavPath // (Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x19e0c40
	void IsBlinded(struct AAIController* AIController, struct UObject* __WorldContext, bool& IsBlinded); // Function AI_Function_Library.AI_Function_Library_C.IsBlinded // (Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
};

