// WidgetBlueprintGeneratedClass AbilityIconPrompt.AbilityIconPrompt_C
// Size: 0x3a0 (Inherited: 0x391)
struct UAbilityIconPrompt_C : UInputIconController_C {
	char pad_391[0x7]; // 0x391(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x398(0x08)

	void Construct(); // Function AbilityIconPrompt.AbilityIconPrompt_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x19e0c40
	void EventOnIconChange(); // Function AbilityIconPrompt.AbilityIconPrompt_C.EventOnIconChange // (BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AbilityIconPrompt(int32_t EntryPoint); // Function AbilityIconPrompt.AbilityIconPrompt_C.ExecuteUbergraph_AbilityIconPrompt // (Final|UbergraphFunction) // @ game+0x19e0c40
};

