// BlueprintGeneratedClass AK_Circle_Lv4_StreamedVideo.AK_Circle_Lv4_StreamedVideo_C
// Size: 0x90 (Inherited: 0x90)
struct UAK_Circle_Lv4_StreamedVideo_C : UStreamedVideoDataAsset {
};

