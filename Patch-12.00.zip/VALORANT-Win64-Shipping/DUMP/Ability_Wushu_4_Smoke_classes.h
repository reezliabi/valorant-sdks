// BlueprintGeneratedClass Ability_Wushu_4_Smoke.Ability_Wushu_4_Smoke_C
// Size: 0x1251 (Inherited: 0x11fa)
struct AAbility_Wushu_4_Smoke_C : AAbility_Base_C {
	char pad_11FA[0x6]; // 0x11fa(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1200(0x08)
	struct UProjectileBending_StateComponent_C* AirBendingState; // 0x1208(0x08)
	struct UUnequipStateComponent* UnequipState; // 0x1210(0x08)
	struct UEquipStateComponent* EquipState; // 0x1218(0x08)
	struct UCheckResourcesStateComponent* CheckResourcesState; // 0x1220(0x08)
	struct UConsumeResourcesStateComponent* ConsumeResourcesState; // 0x1228(0x08)
	struct UTimedStateComponent* ReequipTime; // 0x1230(0x08)
	struct UEquipmentChargeComponent* EquipmentCharge; // 0x1238(0x08)
	struct UTimedStateComponent* CommitTime; // 0x1240(0x08)
	struct UProjectileThrowStateComponent* ProjectileThrowState; // 0x1248(0x08)
	bool StoppedDuringCommitTime; // 0x1250(0x01)

	struct UBaseCrosshairHudElement* GetCurrentCrosshairHudElementClass(); // Function Ability_Wushu_4_Smoke.Ability_Wushu_4_Smoke_C.GetCurrentCrosshairHudElementClass // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x19e0c40
	void ReceiveBeginPlay(); // Function Ability_Wushu_4_Smoke.Ability_Wushu_4_Smoke_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__AirBendingState_K2Node_ComponentBoundEvent_0_OnProjectileStopped__DelegateSignature(); // Function Ability_Wushu_4_Smoke.Ability_Wushu_4_Smoke_C.BndEvt__AirBendingState_K2Node_ComponentBoundEvent_0_OnProjectileStopped__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__Ability_Wushu_4_Smoke_CommitTime_K2Node_ComponentBoundEvent_3_OnStateEnterSignature__DelegateSignature(struct UScriptStateComponent* EnteredState, struct UStateTransitionContext* StateTransitionContext, float StartTimeOffset); // Function Ability_Wushu_4_Smoke.Ability_Wushu_4_Smoke_C.BndEvt__Ability_Wushu_4_Smoke_CommitTime_K2Node_ComponentBoundEvent_3_OnStateEnterSignature__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__Ability_Wushu_4_Smoke_CommitTime_K2Node_ComponentBoundEvent_4_OnStateExitSignature__DelegateSignature(struct UScriptStateComponent* ExitedState, struct UStateTransitionContext* StateTransitionContext); // Function Ability_Wushu_4_Smoke.Ability_Wushu_4_Smoke_C.BndEvt__Ability_Wushu_4_Smoke_CommitTime_K2Node_ComponentBoundEvent_4_OnStateExitSignature__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__Ability_Wushu_4_Smoke_AirBendingState_K2Node_ComponentBoundEvent_5_OnStateEnterSignature__DelegateSignature(struct UScriptStateComponent* EnteredState, struct UStateTransitionContext* StateTransitionContext, float StartTimeOffset); // Function Ability_Wushu_4_Smoke.Ability_Wushu_4_Smoke_C.BndEvt__Ability_Wushu_4_Smoke_AirBendingState_K2Node_ComponentBoundEvent_5_OnStateEnterSignature__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void StoppedDuringCommit(); // Function Ability_Wushu_4_Smoke.Ability_Wushu_4_Smoke_C.StoppedDuringCommit // (Net|NetReliableNetClient|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void StopProjectile(); // Function Ability_Wushu_4_Smoke.Ability_Wushu_4_Smoke_C.StopProjectile // (BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void AuthProjectileStopped(); // Function Ability_Wushu_4_Smoke.Ability_Wushu_4_Smoke_C.AuthProjectileStopped // (BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_Ability_Wushu_4_Smoke(int32_t EntryPoint); // Function Ability_Wushu_4_Smoke.Ability_Wushu_4_Smoke_C.ExecuteUbergraph_Ability_Wushu_4_Smoke // (Final|UbergraphFunction|HasDefaults) // @ game+0x19e0c40
};

