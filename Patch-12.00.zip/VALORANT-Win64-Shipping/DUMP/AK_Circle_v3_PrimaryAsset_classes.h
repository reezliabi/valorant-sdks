// BlueprintGeneratedClass AK_Circle_v3_PrimaryAsset.AK_Circle_v3_PrimaryAsset_C
// Size: 0x170 (Inherited: 0x170)
struct UAK_Circle_v3_PrimaryAsset_C : UEquippableSkinChromaDataAsset {
};

