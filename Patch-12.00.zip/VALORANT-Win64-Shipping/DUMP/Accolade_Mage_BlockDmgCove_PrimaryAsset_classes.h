// BlueprintGeneratedClass Accolade_Mage_BlockDmgCove_PrimaryAsset.Accolade_Mage_BlockDmgCove_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Mage_BlockDmgCove_PrimaryAsset_C : UAccoladeDataAsset {
};

