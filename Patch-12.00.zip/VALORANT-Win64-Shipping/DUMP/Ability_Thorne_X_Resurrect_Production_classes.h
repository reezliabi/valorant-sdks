// BlueprintGeneratedClass Ability_Thorne_X_Resurrect_Production.Ability_Thorne_X_Resurrect_Production_C
// Size: 0x12c4 (Inherited: 0x1242)
struct AAbility_Thorne_X_Resurrect_Production_C : AAbility_Equipped_Base_C {
	char pad_1242[0x6]; // 0x1242(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1248(0x08)
	struct UScriptStateComponent* ScriptState_ExploitCorpse; // 0x1250(0x08)
	struct UScriptStateComponent* ScriptState_EQS_FailState; // 0x1258(0x08)
	struct UApplyBuffToTargetsStateComponent* ApplyResurrectionAssistBuff; // 0x1260(0x08)
	struct UUltimateVOComponent_C* AbilityVOComponent; // 0x1268(0x08)
	struct UEQSStateComponent* EQSState; // 0x1270(0x08)
	struct UComp_Equippable_UltActiveOnTimer_C* Comp_Equippable_UltActiveOnTimer; // 0x1278(0x08)
	struct UApplyBuffToTargetsStateComponent* ApplyInvulnerabilityBuff; // 0x1280(0x08)
	struct UApplyBuffToTargetsStateComponent* ApplyResurrectionBuff; // 0x1288(0x08)
	struct UWaitForResourcesStateComponent* WaitForResourcesState; // 0x1290(0x08)
	struct UResurrectPawns_StateComponent_C* ResurrectPawns_StateComponent; // 0x1298(0x08)
	struct UUltPointsComponent* UltPoints; // 0x12a0(0x08)
	struct UExploitCorpseStateComponent* ExploitCorpseState; // 0x12a8(0x08)
	struct UConsumeResourcesStateComponent* ConsumeResourcesState; // 0x12b0(0x08)
	struct UCorpseTargetingStateComponent_C* CorpseTargetingStateComponent; // 0x12b8(0x08)
	int32_t ResurrectionTargetTelemetryEvent; // 0x12c0(0x04)

	void ReceiveBeginPlay(); // Function Ability_Thorne_X_Resurrect_Production.Ability_Thorne_X_Resurrect_Production_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__EQSState_K2Node_ComponentBoundEvent_0_OnStateEnterSignature__DelegateSignature(struct UScriptStateComponent* EnteredState, struct UStateTransitionContext* StateTransitionContext, float StartTimeOffset); // Function Ability_Thorne_X_Resurrect_Production.Ability_Thorne_X_Resurrect_Production_C.BndEvt__EQSState_K2Node_ComponentBoundEvent_0_OnStateEnterSignature__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__ResurrectPawns_StateComponent_K2Node_ComponentBoundEvent_1_OnStateExitSignature__DelegateSignature(struct UScriptStateComponent* ExitedState, struct UStateTransitionContext* StateTransitionContext); // Function Ability_Thorne_X_Resurrect_Production.Ability_Thorne_X_Resurrect_Production_C.BndEvt__ResurrectPawns_StateComponent_K2Node_ComponentBoundEvent_1_OnStateExitSignature__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__EQSState_K2Node_ComponentBoundEvent_0_OnStateExitSignature__DelegateSignature(struct UScriptStateComponent* ExitedState, struct UStateTransitionContext* StateTransitionContext); // Function Ability_Thorne_X_Resurrect_Production.Ability_Thorne_X_Resurrect_Production_C.BndEvt__EQSState_K2Node_ComponentBoundEvent_0_OnStateExitSignature__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__ScriptState_ExploitCorpse_K2Node_ComponentBoundEvent_4_OnStateEnterSignature__DelegateSignature(struct UScriptStateComponent* EnteredState, struct UStateTransitionContext* StateTransitionContext, float StartTimeOffset); // Function Ability_Thorne_X_Resurrect_Production.Ability_Thorne_X_Resurrect_Production_C.BndEvt__ScriptState_ExploitCorpse_K2Node_ComponentBoundEvent_4_OnStateEnterSignature__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__ConsumeResourcesState_K2Node_ComponentBoundEvent_6_OnStateEnterSignature__DelegateSignature(struct UScriptStateComponent* EnteredState, struct UStateTransitionContext* StateTransitionContext, float StartTimeOffset); // Function Ability_Thorne_X_Resurrect_Production.Ability_Thorne_X_Resurrect_Production_C.BndEvt__ConsumeResourcesState_K2Node_ComponentBoundEvent_6_OnStateEnterSignature__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__ScriptState_EQS_FailState_K2Node_ComponentBoundEvent_7_OnStateEnterSignature__DelegateSignature(struct UScriptStateComponent* EnteredState, struct UStateTransitionContext* StateTransitionContext, float StartTimeOffset); // Function Ability_Thorne_X_Resurrect_Production.Ability_Thorne_X_Resurrect_Production_C.BndEvt__ScriptState_EQS_FailState_K2Node_ComponentBoundEvent_7_OnStateEnterSignature__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void OnPreEQSQuery_Event_1(); // Function Ability_Thorne_X_Resurrect_Production.Ability_Thorne_X_Resurrect_Production_C.OnPreEQSQuery_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__Ability_Thorne_X_Resurrect_Production_ApplyResurrectionBuff_K2Node_ComponentBoundEvent_3_OnStateEnterSignature__DelegateSignature(struct UScriptStateComponent* EnteredState, struct UStateTransitionContext* StateTransitionContext, float StartTimeOffset); // Function Ability_Thorne_X_Resurrect_Production.Ability_Thorne_X_Resurrect_Production_C.BndEvt__Ability_Thorne_X_Resurrect_Production_ApplyResurrectionBuff_K2Node_ComponentBoundEvent_3_OnStateEnterSignature__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_Ability_Thorne_X_Resurrect_Production(int32_t EntryPoint); // Function Ability_Thorne_X_Resurrect_Production.Ability_Thorne_X_Resurrect_Production_C.ExecuteUbergraph_Ability_Thorne_X_Resurrect_Production // (Final|UbergraphFunction|HasDefaults) // @ game+0x19e0c40
};

