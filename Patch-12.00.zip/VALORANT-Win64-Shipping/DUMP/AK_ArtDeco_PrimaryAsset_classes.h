// BlueprintGeneratedClass AK_ArtDeco_PrimaryAsset.AK_ArtDeco_PrimaryAsset_C
// Size: 0x220 (Inherited: 0x220)
struct UAK_ArtDeco_PrimaryAsset_C : UEquippableSkinDataAsset {
};

