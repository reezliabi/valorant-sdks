// BlueprintGeneratedClass Ability_Wushu_Q_CycloneBoost.Ability_Wushu_Q_CycloneBoost_C
// Size: 0x12e0 (Inherited: 0x1242)
struct AAbility_Wushu_Q_CycloneBoost_C : AAbility_Equipped_Base_C {
	char pad_1242[0x6]; // 0x1242(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1248(0x08)
	struct UStateComponent_AddKillTracker_C* StateComponent_AddKillTracker; // 0x1250(0x08)
	struct USyncStateMachineStateComponent* SyncStateMachineEndState; // 0x1258(0x08)
	struct UTimedStateComponent* BoostFinishTimedState; // 0x1260(0x08)
	struct UEquippableStateMachineComponent* BoostStateMachine; // 0x1268(0x08)
	struct USyncStateMachineStateComponent* SyncStateMachineStartState; // 0x1270(0x08)
	struct UScriptStateComponent* BoostIdleState; // 0x1278(0x08)
	struct UConsumeResourcesStateComponent* ConsumeResourcesState; // 0x1280(0x08)
	struct UEquipmentChargeComponent* EquipmentCharge; // 0x1288(0x08)
	struct UApplyForceModuleStateComponent* ApplyForceModuleState; // 0x1290(0x08)
	struct FName ContinuousNoiseLabel; // 0x1298(0x0c)
	char pad_12A4[0x4]; // 0x12a4(0x04)
	struct FNoiseEventData NoiseEvent; // 0x12a8(0x38)

	void ReceiveBeginPlay(); // Function Ability_Wushu_Q_CycloneBoost.Ability_Wushu_Q_CycloneBoost_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__EquipDelayState_K2Node_ComponentBoundEvent_0_OnStateEnterSignature__DelegateSignature(struct UScriptStateComponent* EnteredState, struct UStateTransitionContext* StateTransitionContext, float StartTimeOffset); // Function Ability_Wushu_Q_CycloneBoost.Ability_Wushu_Q_CycloneBoost_C.BndEvt__EquipDelayState_K2Node_ComponentBoundEvent_0_OnStateEnterSignature__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__Ability_Wushu_Q_CycloneBoost_ApplyForceModuleState_K2Node_ComponentBoundEvent_1_OnStateEnterSignature__DelegateSignature(struct UScriptStateComponent* EnteredState, struct UStateTransitionContext* StateTransitionContext, float StartTimeOffset); // Function Ability_Wushu_Q_CycloneBoost.Ability_Wushu_Q_CycloneBoost_C.BndEvt__Ability_Wushu_Q_CycloneBoost_ApplyForceModuleState_K2Node_ComponentBoundEvent_1_OnStateEnterSignature__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__Ability_Wushu_Q_CycloneBoost_ApplyForceModuleState_K2Node_ComponentBoundEvent_2_OnStateExitSignature__DelegateSignature(struct UScriptStateComponent* ExitedState, struct UStateTransitionContext* StateTransitionContext); // Function Ability_Wushu_Q_CycloneBoost.Ability_Wushu_Q_CycloneBoost_C.BndEvt__Ability_Wushu_Q_CycloneBoost_ApplyForceModuleState_K2Node_ComponentBoundEvent_2_OnStateExitSignature__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_Ability_Wushu_Q_CycloneBoost(int32_t EntryPoint); // Function Ability_Wushu_Q_CycloneBoost.Ability_Wushu_Q_CycloneBoost_C.ExecuteUbergraph_Ability_Wushu_Q_CycloneBoost // (Final|UbergraphFunction) // @ game+0x19e0c40
};

