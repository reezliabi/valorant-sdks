// BlueprintGeneratedClass 13-0_Level1_PrimaryAsset.13-0_Level1_PrimaryAsset_C
// Size: 0xf0 (Inherited: 0xf0)
struct U13-0_Level1_PrimaryAsset_C : USprayLevelDataAsset {
};

