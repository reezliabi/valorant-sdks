// BlueprintGeneratedClass Ability_Sarge_E_SpeedStim.Ability_Sarge_E_SpeedStim_C
// Size: 0x1288 (Inherited: 0x1242)
struct AAbility_Sarge_E_SpeedStim_C : AAbility_Equipped_Base_C {
	char pad_1242[0x6]; // 0x1242(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1248(0x08)
	struct UCheckResourcesStateComponent* CheckResourcesState_Cooldown; // 0x1250(0x08)
	struct UTestBranch_HasCharge_StateComponent_C* TestBranch_HasCharge_StateComponent; // 0x1258(0x08)
	struct UTimedStateComponent* TimedState_Cooldown; // 0x1260(0x08)
	struct UCrosshairComponent* Crosshair; // 0x1268(0x08)
	struct UEquipmentChargeComponent* EquipmentCharge; // 0x1270(0x08)
	struct UConsumeResourcesStateComponent* ConsumeResourcesState; // 0x1278(0x08)
	struct UProjectileThrowStateComponent* ProjectileThrowState; // 0x1280(0x08)

	void ReceiveBeginPlay(); // Function Ability_Sarge_E_SpeedStim.Ability_Sarge_E_SpeedStim_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void EnterInactiveState(struct UScriptStateComponent* EnteredState, struct UStateTransitionContext* StateTransitionContext, float StartTimeOffset); // Function Ability_Sarge_E_SpeedStim.Ability_Sarge_E_SpeedStim_C.EnterInactiveState // (BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_Ability_Sarge_E_SpeedStim(int32_t EntryPoint); // Function Ability_Sarge_E_SpeedStim.Ability_Sarge_E_SpeedStim_C.ExecuteUbergraph_Ability_Sarge_E_SpeedStim // (Final|UbergraphFunction|HasDefaults) // @ game+0x19e0c40
};

