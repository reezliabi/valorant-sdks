// BlueprintGeneratedClass Activate_Ability1ActionTraits.Activate_Ability1ActionTraits_C
// Size: 0xe0 (Inherited: 0xe0)
struct UActivate_Ability1ActionTraits_C : UActionTraits {
};

