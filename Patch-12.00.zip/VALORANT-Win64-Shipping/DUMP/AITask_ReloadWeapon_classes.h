// BlueprintGeneratedClass AITask_ReloadWeapon.AITask_ReloadWeapon_C
// Size: 0xc0 (Inherited: 0xb0)
struct UAITask_ReloadWeapon_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb0(0x08)
	struct UAmmoComponent* Magazine; // 0xb8(0x08)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AITask_ReloadWeapon.AITask_ReloadWeapon_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function AITask_ReloadWeapon.AITask_ReloadWeapon_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AITask_ReloadWeapon(int32_t EntryPoint); // Function AITask_ReloadWeapon.AITask_ReloadWeapon_C.ExecuteUbergraph_AITask_ReloadWeapon // (Final|UbergraphFunction) // @ game+0x19e0c40
};

