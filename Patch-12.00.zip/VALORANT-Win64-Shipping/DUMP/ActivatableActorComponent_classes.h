// BlueprintGeneratedClass ActivatableActorComponent.ActivatableActorComponent_C
// Size: 0x101 (Inherited: 0xd8)
struct UActivatableActorComponent_C : UActorComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd8(0x08)
	struct FMulticastInlineDelegate AuthActivated; // 0xe0(0x10)
	struct FMulticastInlineDelegate AuthDeactivated; // 0xf0(0x10)
	bool IsActivated; // 0x100(0x01)

	void GetIsActivated(bool& Active); // Function ActivatableActorComponent.ActivatableActorComponent_C.GetIsActivated // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x19e0c40
	void AuthToggleActive(struct AActor* ActivatingActor); // Function ActivatableActorComponent.ActivatableActorComponent_C.AuthToggleActive // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void AuthDeactivate(struct AActor* DeactivatingActor); // Function ActivatableActorComponent.ActivatableActorComponent_C.AuthDeactivate // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void AuthActivate(struct AActor* ActivatingActor); // Function ActivatableActorComponent.ActivatableActorComponent_C.AuthActivate // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void AuthResetActivated(bool NewActivated); // Function ActivatableActorComponent.ActivatableActorComponent_C.AuthResetActivated // (BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_ActivatableActorComponent(int32_t EntryPoint); // Function ActivatableActorComponent.ActivatableActorComponent_C.ExecuteUbergraph_ActivatableActorComponent // (Final|UbergraphFunction) // @ game+0x19e0c40
	void AuthDeactivated__DelegateSignature(struct AActor* DeactivatingActor); // Function ActivatableActorComponent.ActivatableActorComponent_C.AuthDeactivated__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void AuthActivated__DelegateSignature(struct AActor* ActivatingActor); // Function ActivatableActorComponent.ActivatableActorComponent_C.AuthActivated__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
};

