// BlueprintGeneratedClass Accolade_Wraith_ParanoiaMultipleEnemies_PrimaryAsset.Accolade_Wraith_ParanoiaMultipleEnemies_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Wraith_ParanoiaMultipleEnemies_PrimaryAsset_C : UAccoladeDataAsset {
};

