// BlueprintGeneratedClass AK_Afterglow_Standard_Chroma.AK_Afterglow_Standard_Chroma_C
// Size: 0x2a8 (Inherited: 0x289)
struct UAK_Afterglow_Standard_Chroma_C : UWeapon_Chroma_Base_C {
	char pad_289[0x7]; // 0x289(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x290(0x08)
	struct TArray<struct FColor> myChromaLEDColors; // 0x298(0x10)

	void ReceiveBeginPlay(); // Function AK_Afterglow_Standard_Chroma.AK_Afterglow_Standard_Chroma_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AK_Afterglow_Standard_Chroma(int32_t EntryPoint); // Function AK_Afterglow_Standard_Chroma.AK_Afterglow_Standard_Chroma_C.ExecuteUbergraph_AK_Afterglow_Standard_Chroma // (Final|UbergraphFunction) // @ game+0x19e0c40
};

