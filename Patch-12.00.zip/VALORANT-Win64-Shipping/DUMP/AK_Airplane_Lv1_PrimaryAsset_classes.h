// BlueprintGeneratedClass AK_Airplane_Lv1_PrimaryAsset.AK_Airplane_Lv1_PrimaryAsset_C
// Size: 0x118 (Inherited: 0x118)
struct UAK_Airplane_Lv1_PrimaryAsset_C : UEquippableSkinLevelDataAsset {
};

