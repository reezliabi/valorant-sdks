// WidgetBlueprintGeneratedClass AccountLevelCarousel.AccountLevelCarousel_C
// Size: 0x3db (Inherited: 0x3db)
struct UAccountLevelCarousel_C : UGenericCarousel_C {

	void HandleSorter(struct UObject* A, struct UObject* B, bool& Value); // Function AccountLevelCarousel.AccountLevelCarousel_C.HandleSorter // (Private|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
};

