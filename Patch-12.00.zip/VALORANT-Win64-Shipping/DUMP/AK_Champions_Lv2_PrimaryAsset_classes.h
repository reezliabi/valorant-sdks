// BlueprintGeneratedClass AK_Champions_Lv2_PrimaryAsset.AK_Champions_Lv2_PrimaryAsset_C
// Size: 0x118 (Inherited: 0x118)
struct UAK_Champions_Lv2_PrimaryAsset_C : UEquippableSkinLevelDataAsset {
};

