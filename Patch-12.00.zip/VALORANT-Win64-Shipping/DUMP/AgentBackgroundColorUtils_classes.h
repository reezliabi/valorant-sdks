// BlueprintGeneratedClass AgentBackgroundColorUtils.AgentBackgroundColorUtils_C
// Size: 0x30 (Inherited: 0x30)
struct UAgentBackgroundColorUtils_C : UBlueprintFunctionLibrary {

	void SetAgentWithCustomCollection(struct UCharacterUIData* Agent, struct UMaterialParameterCollection* Collection, struct UObject* __WorldContext); // Function AgentBackgroundColorUtils.AgentBackgroundColorUtils_C.SetAgentWithCustomCollection // (Static|Public|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void Clear(struct UObject* __WorldContext); // Function AgentBackgroundColorUtils.AgentBackgroundColorUtils_C.Clear // (Static|Public|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void SetAgentToAnimate(struct UCharacterUIData* Agent, struct UObject* __WorldContext); // Function AgentBackgroundColorUtils.AgentBackgroundColorUtils_C.SetAgentToAnimate // (Static|Public|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void SetAgent(struct UCharacterUIData* Agent, struct UObject* __WorldContext); // Function AgentBackgroundColorUtils.AgentBackgroundColorUtils_C.SetAgent // (Static|Public|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
};

