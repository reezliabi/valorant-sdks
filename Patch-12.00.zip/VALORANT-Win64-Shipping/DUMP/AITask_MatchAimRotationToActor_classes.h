// BlueprintGeneratedClass AITask_MatchAimRotationToActor.AITask_MatchAimRotationToActor_C
// Size: 0x128 (Inherited: 0xb0)
struct UAITask_MatchAimRotationToActor_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb0(0x08)
	struct FBlackboardKeySelector BBKey_ActorToMatch; // 0xb8(0x30)
	double FocalPointForwardDistance; // 0xe8(0x08)
	double AimAngleTolerance; // 0xf0(0x08)
	double FailureTime; // 0xf8(0x08)
	double SettleTime; // 0x100(0x08)
	double LastNonMatchingGameTime; // 0x108(0x08)
	struct UAIAimPriorityComponent* AIAimPriorityComponent; // 0x110(0x08)
	enum class EAIAimTargetType MarkupAimTargetType; // 0x118(0x01)
	bool UseAimPrioritySystem; // 0x119(0x01)
	char pad_11A[0x6]; // 0x11a(0x06)
	struct FTimerHandle FailureTimer; // 0x120(0x08)

	void ClearFocus(struct AAIController* Controller); // Function AITask_MatchAimRotationToActor.AITask_MatchAimRotationToActor_C.ClearFocus // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function AITask_MatchAimRotationToActor.AITask_MatchAimRotationToActor_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AITask_MatchAimRotationToActor.AITask_MatchAimRotationToActor_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void FailureTimeout(); // Function AITask_MatchAimRotationToActor.AITask_MatchAimRotationToActor_C.FailureTimeout // (BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void ReceiveAbortAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AITask_MatchAimRotationToActor.AITask_MatchAimRotationToActor_C.ReceiveAbortAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AITask_MatchAimRotationToActor(int32_t EntryPoint); // Function AITask_MatchAimRotationToActor.AITask_MatchAimRotationToActor_C.ExecuteUbergraph_AITask_MatchAimRotationToActor // (Final|UbergraphFunction|HasDefaults) // @ game+0x19e0c40
};

