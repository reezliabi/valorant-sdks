// BlueprintGeneratedClass AimBotsShootableSwitch.AimBotsShootableSwitch_C
// Size: 0x511 (Inherited: 0x510)
struct AAimBotsShootableSwitch_C : AShootableSwitch_C {
	enum class EAimBotsSwitchType SwitchType; // 0x510(0x01)
};

