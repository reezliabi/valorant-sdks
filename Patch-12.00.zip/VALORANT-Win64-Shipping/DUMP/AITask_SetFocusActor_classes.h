// BlueprintGeneratedClass AITask_SetFocusActor.AITask_SetFocusActor_C
// Size: 0xe8 (Inherited: 0xb0)
struct UAITask_SetFocusActor_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb0(0x08)
	struct FBlackboardKeySelector FocusActor; // 0xb8(0x30)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AITask_SetFocusActor.AITask_SetFocusActor_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AITask_SetFocusActor(int32_t EntryPoint); // Function AITask_SetFocusActor.AITask_SetFocusActor_C.ExecuteUbergraph_AITask_SetFocusActor // (Final|UbergraphFunction) // @ game+0x19e0c40
};

