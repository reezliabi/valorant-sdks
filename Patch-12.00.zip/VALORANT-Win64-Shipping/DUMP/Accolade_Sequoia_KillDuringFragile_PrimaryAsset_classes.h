// BlueprintGeneratedClass Accolade_Sequoia_KillDuringFragile_PrimaryAsset.Accolade_Sequoia_KillDuringFragile_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Sequoia_KillDuringFragile_PrimaryAsset_C : UAccoladeDataAsset {
};

