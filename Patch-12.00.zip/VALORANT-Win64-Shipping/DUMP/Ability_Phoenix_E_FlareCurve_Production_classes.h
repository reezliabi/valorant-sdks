// BlueprintGeneratedClass Ability_Phoenix_E_FlareCurve_Production.Ability_Phoenix_E_FlareCurve_Production_C
// Size: 0x12a0 (Inherited: 0x1284)
struct AAbility_Phoenix_E_FlareCurve_Production_C : AAbility_Grenade_Base_C {
	char pad_1284[0x4]; // 0x1284(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1288(0x08)
	struct USignatureAbilityResourceComponent* SignatureAbilityResource; // 0x1290(0x08)
	struct UParticleSystemComponent* FlareAttachedVFX; // 0x1298(0x08)

	struct UBaseCrosshairHudElement* GetCurrentCrosshairHudElementClass(); // Function Ability_Phoenix_E_FlareCurve_Production.Ability_Phoenix_E_FlareCurve_Production_C.GetCurrentCrosshairHudElementClass // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x19e0c40
	void BndEvt__UnequipDelayState_K2Node_ComponentBoundEvent_0_OnStateEnterSignature__DelegateSignature(struct UScriptStateComponent* EnteredState, struct UStateTransitionContext* StateTransitionContext, float StartTimeOffset); // Function Ability_Phoenix_E_FlareCurve_Production.Ability_Phoenix_E_FlareCurve_Production_C.BndEvt__UnequipDelayState_K2Node_ComponentBoundEvent_0_OnStateEnterSignature__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_Ability_Phoenix_E_FlareCurve_Production(int32_t EntryPoint); // Function Ability_Phoenix_E_FlareCurve_Production.Ability_Phoenix_E_FlareCurve_Production_C.ExecuteUbergraph_Ability_Phoenix_E_FlareCurve_Production // (Final|UbergraphFunction) // @ game+0x19e0c40
};

