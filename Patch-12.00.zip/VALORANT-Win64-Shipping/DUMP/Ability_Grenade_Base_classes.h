// BlueprintGeneratedClass Ability_Grenade_Base.Ability_Grenade_Base_C
// Size: 0x1284 (Inherited: 0x1242)
struct AAbility_Grenade_Base_C : AAbility_Equipped_Base_C {
	char pad_1242[0x6]; // 0x1242(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1248(0x08)
	struct UConsumeResourcesStateComponent* ConsumeResourcesUnderhandState; // 0x1250(0x08)
	struct UConsumeResourcesStateComponent* ConsumeResourcesOverhandState; // 0x1258(0x08)
	struct URespondToEventStateComponent* RespondToInputState; // 0x1260(0x08)
	struct UProjectileThrowStateComponent* UnderhandThrowState; // 0x1268(0x08)
	struct UProjectileThrowStateComponent* OverhandThrowState; // 0x1270(0x08)
	struct UBaseCrosshairHudElement* CrosshairHUDElement; // 0x1278(0x08)
	bool HasUnderhand; // 0x1280(0x01)
	bool CanBeThrownInPreround; // 0x1281(0x01)
	enum class EAresEquippableInput OverhandInput; // 0x1282(0x01)
	enum class EAresEquippableInput UnderhandInput; // 0x1283(0x01)

	struct UBaseCrosshairHudElement* GetCurrentCrosshairHudElementClass(); // Function Ability_Grenade_Base.Ability_Grenade_Base_C.GetCurrentCrosshairHudElementClass // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x19e0c40
	void ReceiveBeginPlay(); // Function Ability_Grenade_Base.Ability_Grenade_Base_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_Ability_Grenade_Base(int32_t EntryPoint); // Function Ability_Grenade_Base.Ability_Grenade_Base_C.ExecuteUbergraph_Ability_Grenade_Base // (Final|UbergraphFunction|HasDefaults) // @ game+0x19e0c40
};

