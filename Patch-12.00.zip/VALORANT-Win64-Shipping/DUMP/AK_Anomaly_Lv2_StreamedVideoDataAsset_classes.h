// BlueprintGeneratedClass AK_Anomaly_Lv2_StreamedVideoDataAsset.AK_Anomaly_Lv2_StreamedVideoDataAsset_C
// Size: 0x90 (Inherited: 0x90)
struct UAK_Anomaly_Lv2_StreamedVideoDataAsset_C : UStreamedVideoDataAsset {
};

