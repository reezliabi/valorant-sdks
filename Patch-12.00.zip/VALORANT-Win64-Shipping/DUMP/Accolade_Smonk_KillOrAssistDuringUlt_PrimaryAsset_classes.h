// BlueprintGeneratedClass Accolade_Smonk_KillOrAssistDuringUlt_PrimaryAsset.Accolade_Smonk_KillOrAssistDuringUlt_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Smonk_KillOrAssistDuringUlt_PrimaryAsset_C : UAccoladeDataAsset {
};

