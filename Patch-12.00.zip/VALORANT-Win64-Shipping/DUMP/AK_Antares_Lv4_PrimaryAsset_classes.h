// BlueprintGeneratedClass AK_Antares_Lv4_PrimaryAsset.AK_Antares_Lv4_PrimaryAsset_C
// Size: 0x118 (Inherited: 0x118)
struct UAK_Antares_Lv4_PrimaryAsset_C : UEquippableSkinLevelDataAsset {
};

