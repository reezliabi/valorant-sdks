// BlueprintGeneratedClass AK_Anomaly_v1_PrimaryAsset.AK_Anomaly_v1_PrimaryAsset_C
// Size: 0x170 (Inherited: 0x170)
struct UAK_Anomaly_v1_PrimaryAsset_C : UEquippableSkinChromaDataAsset {
};

