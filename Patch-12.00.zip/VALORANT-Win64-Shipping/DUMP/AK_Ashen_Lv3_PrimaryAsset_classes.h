// BlueprintGeneratedClass AK_Ashen_Lv3_PrimaryAsset.AK_Ashen_Lv3_PrimaryAsset_C
// Size: 0x118 (Inherited: 0x118)
struct UAK_Ashen_Lv3_PrimaryAsset_C : UEquippableSkinLevelDataAsset {
};

