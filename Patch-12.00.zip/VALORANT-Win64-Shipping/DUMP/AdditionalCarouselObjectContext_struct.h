// UserDefinedStruct AdditionalCarouselObjectContext.AdditionalCarouselObjectContext
// Size: 0x01 (Inherited: 0x00)
struct FAdditionalCarouselObjectContext {
	bool IsJuiceContent_1_0262ADB3437FE39C5B6BE3BBE716E595; // 0x00(0x01)
};

