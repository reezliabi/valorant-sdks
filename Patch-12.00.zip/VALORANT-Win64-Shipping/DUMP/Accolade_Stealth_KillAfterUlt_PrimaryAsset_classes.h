// BlueprintGeneratedClass Accolade_Stealth_KillAfterUlt_PrimaryAsset.Accolade_Stealth_KillAfterUlt_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Stealth_KillAfterUlt_PrimaryAsset_C : UAccoladeDataAsset {
};

