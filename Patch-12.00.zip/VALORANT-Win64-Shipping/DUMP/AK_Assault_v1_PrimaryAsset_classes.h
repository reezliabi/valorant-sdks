// BlueprintGeneratedClass AK_Assault_v1_PrimaryAsset.AK_Assault_v1_PrimaryAsset_C
// Size: 0x170 (Inherited: 0x170)
struct UAK_Assault_v1_PrimaryAsset_C : UEquippableSkinChromaDataAsset {
};

