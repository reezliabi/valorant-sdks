// BlueprintGeneratedClass AK_Cyberpunk2_Gold_PrimaryAsset.AK_Cyberpunk2_Gold_PrimaryAsset_C
// Size: 0x170 (Inherited: 0x170)
struct UAK_Cyberpunk2_Gold_PrimaryAsset_C : UEquippableSkinChromaDataAsset {
};

