// BlueprintGeneratedClass 9-3Curse_PrimaryAsset.9-3Curse_PrimaryAsset_C
// Size: 0xd8 (Inherited: 0xd8)
struct U9-3Curse_PrimaryAsset_C : USprayDataAsset {
};

