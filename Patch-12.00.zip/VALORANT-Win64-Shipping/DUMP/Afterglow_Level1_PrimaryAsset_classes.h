// BlueprintGeneratedClass Afterglow_Level1_PrimaryAsset.Afterglow_Level1_PrimaryAsset_C
// Size: 0xf0 (Inherited: 0xf0)
struct UAfterglow_Level1_PrimaryAsset_C : USprayLevelDataAsset {
};

