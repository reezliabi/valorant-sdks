// BlueprintGeneratedClass Accolade_Grenadier_YouOrAllyKillsOffUlt_PrimaryAsset.Accolade_Grenadier_YouOrAllyKillsOffUlt_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Grenadier_YouOrAllyKillsOffUlt_PrimaryAsset_C : UAccoladeDataAsset {
};

