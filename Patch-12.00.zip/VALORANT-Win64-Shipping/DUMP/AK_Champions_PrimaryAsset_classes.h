// BlueprintGeneratedClass AK_Champions_PrimaryAsset.AK_Champions_PrimaryAsset_C
// Size: 0x220 (Inherited: 0x220)
struct UAK_Champions_PrimaryAsset_C : UEquippableSkinDataAsset {
};

