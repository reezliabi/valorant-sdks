// BlueprintGeneratedClass AK_Astronaut_PrimaryAsset.AK_Astronaut_PrimaryAsset_C
// Size: 0x220 (Inherited: 0x220)
struct UAK_Astronaut_PrimaryAsset_C : UEquippableSkinDataAsset {
};

