// BlueprintGeneratedClass Accolade_Breach_RollingThunderMultipleEnemies_PrimaryAsset.Accolade_Breach_RollingThunderMultipleEnemies_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Breach_RollingThunderMultipleEnemies_PrimaryAsset_C : UAccoladeDataAsset {
};

