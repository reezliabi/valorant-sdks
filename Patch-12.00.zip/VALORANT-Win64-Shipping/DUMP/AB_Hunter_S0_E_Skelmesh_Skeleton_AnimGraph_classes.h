// AnimBlueprintGeneratedClass AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph.AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph_C
// Size: 0xda0 (Inherited: 0x390)
struct UAB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x390(0x08)
	struct FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables; // 0x398(0x0c)
	char pad_3A4[0x4]; // 0x3a4(0x04)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess; // 0x3a8(0x08)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base; // 0x3b0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x3b8(0x20)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // 0x3d8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // 0x400(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x428(0x48)
	struct FAnimNode_ApplyMeshSpaceAdditive AnimGraphNode_ApplyMeshSpaceAdditive; // 0x470(0xd8)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer; // 0x548(0xa0)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // 0x5e8(0x20)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x608(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0x650(0x20)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0x670(0x100)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x770(0x50)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_4; // 0x7c0(0x138)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // 0x8f8(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0x918(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3; // 0x938(0x138)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2; // 0xa70(0x138)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone; // 0xba8(0x138)
	enum class Enum_Hunter_Drone_States DroneState; // 0xce0(0x01)
	char pad_CE1[0x7]; // 0xce1(0x07)
	double ForwardSpeed; // 0xce8(0x08)
	double StrafeSpeed; // 0xcf0(0x08)
	struct FRotator CurrentLookRotation; // 0xcf8(0x18)
	struct FExplicitFloatCurve HeadTranslactionByPitch; // 0xd10(0x88)
	double CurrentHeadTranslation; // 0xd98(0x08)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph.AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void EvaluateGraphExposedInputs_ExecuteUbergraph_AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph_AnimGraphNode_ModifyBone_06BE1C014DD3C6770D4CA39EF1B8BF25(); // Function AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph.AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph_C.EvaluateGraphExposedInputs_ExecuteUbergraph_AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph_AnimGraphNode_ModifyBone_06BE1C014DD3C6770D4CA39EF1B8BF25 // (BlueprintEvent) // @ game+0x19e0c40
	void EvaluateGraphExposedInputs_ExecuteUbergraph_AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph_AnimGraphNode_ModifyBone_8E4B8D7B49E7292CF11B86A3E545A3CF(); // Function AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph.AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph_C.EvaluateGraphExposedInputs_ExecuteUbergraph_AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph_AnimGraphNode_ModifyBone_8E4B8D7B49E7292CF11B86A3E545A3CF // (BlueprintEvent) // @ game+0x19e0c40
	void EvaluateGraphExposedInputs_ExecuteUbergraph_AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph_AnimGraphNode_ModifyBone_3CBD4EB64DAEAF78EA2DE0A1CBBA3C01(); // Function AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph.AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph_C.EvaluateGraphExposedInputs_ExecuteUbergraph_AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph_AnimGraphNode_ModifyBone_3CBD4EB64DAEAF78EA2DE0A1CBBA3C01 // (BlueprintEvent) // @ game+0x19e0c40
	void EvaluateGraphExposedInputs_ExecuteUbergraph_AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph_AnimGraphNode_ModifyBone_BE0C752D484B85D5DEE63B96CC910CCE(); // Function AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph.AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph_C.EvaluateGraphExposedInputs_ExecuteUbergraph_AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph_AnimGraphNode_ModifyBone_BE0C752D484B85D5DEE63B96CC910CCE // (BlueprintEvent) // @ game+0x19e0c40
	void EvaluateGraphExposedInputs_ExecuteUbergraph_AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph_AnimGraphNode_TransitionResult_769C6CB6416D7055701935A8E919D719(); // Function AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph.AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph_C.EvaluateGraphExposedInputs_ExecuteUbergraph_AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph_AnimGraphNode_TransitionResult_769C6CB6416D7055701935A8E919D719 // (BlueprintEvent) // @ game+0x19e0c40
	void EvaluateGraphExposedInputs_ExecuteUbergraph_AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph_AnimGraphNode_TransitionResult_5AC870164F7A19164FE28C9D57F1E120(); // Function AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph.AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph_C.EvaluateGraphExposedInputs_ExecuteUbergraph_AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph_AnimGraphNode_TransitionResult_5AC870164F7A19164FE28C9D57F1E120 // (BlueprintEvent) // @ game+0x19e0c40
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph.AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph(int32_t EntryPoint); // Function AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph.AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph_C.ExecuteUbergraph_AB_Hunter_S0_E_Skelmesh_Skeleton_AnimGraph // (Final|UbergraphFunction) // @ game+0x19e0c40
};

