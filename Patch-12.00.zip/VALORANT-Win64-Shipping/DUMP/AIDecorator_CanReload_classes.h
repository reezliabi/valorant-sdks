// BlueprintGeneratedClass AIDecorator_CanReload.AIDecorator_CanReload_C
// Size: 0xa8 (Inherited: 0xa8)
struct UAIDecorator_CanReload_C : UBTDecorator_BlueprintBase {

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIDecorator_CanReload.AIDecorator_CanReload_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
};

