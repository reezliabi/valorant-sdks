// BlueprintGeneratedClass 9mmShellCasing.9mmShellCasing_C
// Size: 0x630 (Inherited: 0x630)
struct A9mmShellCasing_C : ABaseShellCasing_C {
};

