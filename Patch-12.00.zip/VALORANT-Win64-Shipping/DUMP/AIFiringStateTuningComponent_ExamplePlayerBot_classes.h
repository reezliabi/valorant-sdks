// BlueprintGeneratedClass AIFiringStateTuningComponent_ExamplePlayerBot.AIFiringStateTuningComponent_ExamplePlayerBot_C
// Size: 0xfa (Inherited: 0xe0)
struct UAIFiringStateTuningComponent_ExamplePlayerBot_C : UAIFiringStateTuningComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xe0(0x08)
	double MaxDamageLimit; // 0xe8(0x08)
	double TrackingPlayerDamage; // 0xf0(0x08)
	bool LimitDamage; // 0xf8(0x01)
	bool ShotModified; // 0xf9(0x01)

	void Firing Period End(); // Function AIFiringStateTuningComponent_ExamplePlayerBot.AIFiringStateTuningComponent_ExamplePlayerBot_C.Firing Period End // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void ModifyShotTrajectories(struct FVector& FiringLocation, struct TArray<struct FVector>& AttackVectors, struct FProjectileTuning& ProjectileTuning); // Function AIFiringStateTuningComponent_ExamplePlayerBot.AIFiringStateTuningComponent_ExamplePlayerBot_C.ModifyShotTrajectories // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void ReceiveBeginPlay(); // Function AIFiringStateTuningComponent_ExamplePlayerBot.AIFiringStateTuningComponent_ExamplePlayerBot_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x19e0c40
	void OnPlayerCharacterHit(float Damage); // Function AIFiringStateTuningComponent_ExamplePlayerBot.AIFiringStateTuningComponent_ExamplePlayerBot_C.OnPlayerCharacterHit // (Event|Public|BlueprintEvent) // @ game+0x19e0c40
	void OnRoundBegin(int32_t RoundNumberBeginning); // Function AIFiringStateTuningComponent_ExamplePlayerBot.AIFiringStateTuningComponent_ExamplePlayerBot_C.OnRoundBegin // (BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AIFiringStateTuningComponent_ExamplePlayerBot(int32_t EntryPoint); // Function AIFiringStateTuningComponent_ExamplePlayerBot.AIFiringStateTuningComponent_ExamplePlayerBot_C.ExecuteUbergraph_AIFiringStateTuningComponent_ExamplePlayerBot // (Final|UbergraphFunction) // @ game+0x19e0c40
};

