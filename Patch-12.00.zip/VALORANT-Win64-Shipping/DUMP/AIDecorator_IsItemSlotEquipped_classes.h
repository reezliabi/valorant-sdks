// BlueprintGeneratedClass AIDecorator_IsItemSlotEquipped.AIDecorator_IsItemSlotEquipped_C
// Size: 0xa9 (Inherited: 0xa8)
struct UAIDecorator_IsItemSlotEquipped_C : UBTDecorator_BlueprintBase {
	enum class EAresItemSlot Slot; // 0xa8(0x01)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIDecorator_IsItemSlotEquipped.AIDecorator_IsItemSlotEquipped_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
};

