// BlueprintGeneratedClass Accolade_Phoenix_KillAfterFlash_PrimaryAsset.Accolade_Phoenix_KillAfterFlash_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Phoenix_KillAfterFlash_PrimaryAsset_C : UAccoladeDataAsset {
};

