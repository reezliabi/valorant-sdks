// BlueprintGeneratedClass AIUpdateMovementAimTargetComponent_ExamplePlayerBot.AIUpdateMovementAimTargetComponent_ExamplePlayerBot_C
// Size: 0x110 (Inherited: 0xe0)
struct UAIUpdateMovementAimTargetComponent_ExamplePlayerBot_C : UAIUpdateMovementAimTargetComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xe0(0x08)
	struct UAIAimPriorityComponent* AimPriorityComponent; // 0xe8(0x08)
	double DefaultPriority; // 0xf0(0x08)
	double PreroundMovementPriority; // 0xf8(0x08)
	bool HasDefaultPriority; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
	double MinSpeed; // 0x108(0x08)

	void ReceiveBeginPlay(); // Function AIUpdateMovementAimTargetComponent_ExamplePlayerBot.AIUpdateMovementAimTargetComponent_ExamplePlayerBot_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x19e0c40
	void OnGamePhaseChanged(enum class EAresGamePhase NewGamePhase, int32_t RoundNumberEnded); // Function AIUpdateMovementAimTargetComponent_ExamplePlayerBot.AIUpdateMovementAimTargetComponent_ExamplePlayerBot_C.OnGamePhaseChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
	void ReceiveTick(float DeltaSeconds); // Function AIUpdateMovementAimTargetComponent_ExamplePlayerBot.AIUpdateMovementAimTargetComponent_ExamplePlayerBot_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AIUpdateMovementAimTargetComponent_ExamplePlayerBot(int32_t EntryPoint); // Function AIUpdateMovementAimTargetComponent_ExamplePlayerBot.AIUpdateMovementAimTargetComponent_ExamplePlayerBot_C.ExecuteUbergraph_AIUpdateMovementAimTargetComponent_ExamplePlayerBot // (Final|UbergraphFunction) // @ game+0x19e0c40
};

