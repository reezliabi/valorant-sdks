// BlueprintGeneratedClass AK_Daedalus_Lv1_StreamedVideo.AK_Daedalus_Lv1_StreamedVideo_C
// Size: 0x90 (Inherited: 0x90)
struct UAK_Daedalus_Lv1_StreamedVideo_C : UStreamedVideoDataAsset {
};

