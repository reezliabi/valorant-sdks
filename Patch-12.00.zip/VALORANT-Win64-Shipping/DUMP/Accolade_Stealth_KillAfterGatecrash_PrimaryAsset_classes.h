// BlueprintGeneratedClass Accolade_Stealth_KillAfterGatecrash_PrimaryAsset.Accolade_Stealth_KillAfterGatecrash_PrimaryAsset_C
// Size: 0xb0 (Inherited: 0xb0)
struct UAccolade_Stealth_KillAfterGatecrash_PrimaryAsset_C : UAccoladeDataAsset {
};

