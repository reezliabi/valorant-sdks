// BlueprintGeneratedClass AK_Ashen_PrimaryAsset.AK_Ashen_PrimaryAsset_C
// Size: 0x220 (Inherited: 0x220)
struct UAK_Ashen_PrimaryAsset_C : UEquippableSkinDataAsset {
};

