// BlueprintGeneratedClass AITask_CopyBlackboardVector.AITask_CopyBlackboardVector_C
// Size: 0x118 (Inherited: 0xb0)
struct UAITask_CopyBlackboardVector_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb0(0x08)
	struct FBlackboardKeySelector Source; // 0xb8(0x30)
	struct FBlackboardKeySelector Destination; // 0xe8(0x30)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AITask_CopyBlackboardVector.AITask_CopyBlackboardVector_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AITask_CopyBlackboardVector(int32_t EntryPoint); // Function AITask_CopyBlackboardVector.AITask_CopyBlackboardVector_C.ExecuteUbergraph_AITask_CopyBlackboardVector // (Final|UbergraphFunction) // @ game+0x19e0c40
};

