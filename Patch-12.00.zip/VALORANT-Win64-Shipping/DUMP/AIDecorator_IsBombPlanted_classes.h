// BlueprintGeneratedClass AIDecorator_IsBombPlanted.AIDecorator_IsBombPlanted_C
// Size: 0xb0 (Inherited: 0xa8)
struct UAIDecorator_IsBombPlanted_C : UBTDecorator_BlueprintBase {
	struct APlantedBomb_C* PlantedBomb; // 0xa8(0x08)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIDecorator_IsBombPlanted.AIDecorator_IsBombPlanted_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x19e0c40
};

