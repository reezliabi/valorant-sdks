// BlueprintGeneratedClass AK_AbstractHeroes_PrimaryAsset.AK_AbstractHeroes_PrimaryAsset_C
// Size: 0x220 (Inherited: 0x220)
struct UAK_AbstractHeroes_PrimaryAsset_C : UEquippableSkinDataAsset {
};

