// BlueprintGeneratedClass AITask_FocalPoint_StraightAhead.AITask_FocalPoint_StraightAhead_C
// Size: 0xb8 (Inherited: 0xb0)
struct UAITask_FocalPoint_StraightAhead_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb0(0x08)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AITask_FocalPoint_StraightAhead.AITask_FocalPoint_StraightAhead_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AITask_FocalPoint_StraightAhead(int32_t EntryPoint); // Function AITask_FocalPoint_StraightAhead.AITask_FocalPoint_StraightAhead_C.ExecuteUbergraph_AITask_FocalPoint_StraightAhead // (Final|UbergraphFunction) // @ game+0x19e0c40
};

