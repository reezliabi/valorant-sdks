// BlueprintGeneratedClass AITask_UnZoomEquippedWeapon.AITask_UnZoomEquippedWeapon_C
// Size: 0xb8 (Inherited: 0xb0)
struct UAITask_UnZoomEquippedWeapon_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb0(0x08)

	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function AITask_UnZoomEquippedWeapon.AITask_UnZoomEquippedWeapon_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_AITask_UnZoomEquippedWeapon(int32_t EntryPoint); // Function AITask_UnZoomEquippedWeapon.AITask_UnZoomEquippedWeapon_C.ExecuteUbergraph_AITask_UnZoomEquippedWeapon // (Final|UbergraphFunction) // @ game+0x19e0c40
};

