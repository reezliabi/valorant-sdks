// BlueprintGeneratedClass Ability_Equipped_Base.Ability_Equipped_Base_C
// Size: 0x1242 (Inherited: 0x11fa)
struct AAbility_Equipped_Base_C : AAbility_Base_C {
	char pad_11FA[0x6]; // 0x11fa(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1200(0x08)
	struct UTimedStateComponent* UnequipDelayState; // 0x1208(0x08)
	struct UUnequipStateComponent* UnequipState; // 0x1210(0x08)
	struct UTimedStateComponent* EquipDelayState; // 0x1218(0x08)
	struct UEquipStateComponent* EquipAbilityState; // 0x1220(0x08)
	struct UCheckResourcesStateComponent* CheckResourcesState; // 0x1228(0x08)
	bool CanBeEquippedOutOfGameplay; // 0x1230(0x01)
	char pad_1231[0x7]; // 0x1231(0x07)
	struct UBaseCrosshairHudElement* AbilityCrosshair; // 0x1238(0x08)
	bool Can Be Equipped in Spawn Zones; // 0x1240(0x01)
	bool Can Respond While Suppressed; // 0x1241(0x01)

	bool CanAutoEquip(); // Function Ability_Equipped_Base.Ability_Equipped_Base_C.CanAutoEquip // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x19e0c40
	struct UBaseCrosshairHudElement* GetCurrentCrosshairHudElementClass(); // Function Ability_Equipped_Base.Ability_Equipped_Base_C.GetCurrentCrosshairHudElementClass // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x19e0c40
	void ReceiveBeginPlay(); // Function Ability_Equipped_Base.Ability_Equipped_Base_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_Ability_Equipped_Base(int32_t EntryPoint); // Function Ability_Equipped_Base.Ability_Equipped_Base_C.ExecuteUbergraph_Ability_Equipped_Base // (Final|UbergraphFunction|HasDefaults) // @ game+0x19e0c40
};

