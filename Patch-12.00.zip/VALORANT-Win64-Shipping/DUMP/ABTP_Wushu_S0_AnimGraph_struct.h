// ScriptStruct ABTP_Wushu_S0_AnimGraph.ABTP_Wushu_S0_AnimGraph_C.AnimBlueprintGeneratedMutableData
// Size: 0x01 (Inherited: 0x01)
struct FAnimBlueprintGeneratedMutableData : FAnimBlueprintMutableData {
};

// ScriptStruct ABTP_Wushu_S0_AnimGraph.ABTP_Wushu_S0_AnimGraph_C.AnimBlueprintGeneratedConstantData
// Size: 0x118 (Inherited: 0x01)
struct FAnimBlueprintGeneratedConstantData : FAnimBlueprintConstantData {
	char pad_1[0x3]; // 0x01(0x03)
	struct FName __NameProperty_11; // 0x04(0x0c)
	struct FAnimNodeFunctionRef __StructProperty_12; // 0x10(0x28)
	bool __BoolProperty_13; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	float __FloatProperty_14; // 0x3c(0x04)
	struct FInputScaleBiasClampConstants __StructProperty_15; // 0x40(0x2c)
	float __FloatProperty_16; // 0x6c(0x04)
	bool __BoolProperty_17; // 0x70(0x01)
	enum class EAnimSyncMethod __EnumProperty_18; // 0x71(0x01)
	enum class EAnimGroupRole __ByteProperty_19; // 0x72(0x01)
	char pad_73[0x1]; // 0x73(0x01)
	struct FName __NameProperty_20; // 0x74(0x0c)
	struct FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess; // 0x80(0x80)
	struct FAnimSubsystem_Base AnimBlueprintExtension_Base; // 0x100(0x18)
};

