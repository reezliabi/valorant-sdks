// BlueprintGeneratedClass AK_Afterglow_Lv1_Skin.AK_Afterglow_Lv1_Skin_C
// Size: 0x518 (Inherited: 0x518)
struct UAK_Afterglow_Lv1_Skin_C : UWeapon_Skin_Base_C {
};

