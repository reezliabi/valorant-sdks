// BlueprintGeneratedClass AK_Afterglow_Lv2_Skin.AK_Afterglow_Lv2_Skin_C
// Size: 0x518 (Inherited: 0x518)
struct UAK_Afterglow_Lv2_Skin_C : UAK_Afterglow_Lv1_Skin_C {
};

