// BlueprintGeneratedClass AK_Circle_PrimaryAsset.AK_Circle_PrimaryAsset_C
// Size: 0x220 (Inherited: 0x220)
struct UAK_Circle_PrimaryAsset_C : UEquippableSkinDataAsset {
};

