// BlueprintGeneratedClass AK_Anomaly_Standard_PrimaryAsset.AK_Anomaly_Standard_PrimaryAsset_C
// Size: 0x170 (Inherited: 0x170)
struct UAK_Anomaly_Standard_PrimaryAsset_C : UEquippableSkinChromaDataAsset {
};

