// ScriptStruct AB_Sarge_S0_E_AnimGraph.AB_Sarge_S0_E_AnimGraph_C.AnimBlueprintGeneratedMutableData
// Size: 0x01 (Inherited: 0x01)
struct FAnimBlueprintGeneratedMutableData : FAnimBlueprintMutableData {
};

// ScriptStruct AB_Sarge_S0_E_AnimGraph.AB_Sarge_S0_E_AnimGraph_C.AnimBlueprintGeneratedConstantData
// Size: 0xe0 (Inherited: 0x01)
struct FAnimBlueprintGeneratedConstantData : FAnimBlueprintConstantData {
	char pad_1[0x3]; // 0x01(0x03)
	struct FName __NameProperty_5; // 0x04(0x0c)
	struct FName __NameProperty_6; // 0x10(0x0c)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FAnimNodeFunctionRef __StructProperty_7; // 0x20(0x28)
	struct FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess; // 0x48(0x80)
	struct FAnimSubsystem_Base AnimBlueprintExtension_Base; // 0xc8(0x18)
};

