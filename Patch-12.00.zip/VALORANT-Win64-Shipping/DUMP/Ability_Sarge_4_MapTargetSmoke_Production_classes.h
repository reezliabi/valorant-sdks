// BlueprintGeneratedClass Ability_Sarge_4_MapTargetSmoke_Production.Ability_Sarge_4_MapTargetSmoke_Production_C
// Size: 0x1288 (Inherited: 0x1242)
struct AAbility_Sarge_4_MapTargetSmoke_Production_C : AAbility_Equipped_Base_C {
	char pad_1242[0x6]; // 0x1242(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1248(0x08)
	struct UMapTargetingStateComponent* MapTargetingState; // 0x1250(0x08)
	struct UEquippableVisibilityComponent* EquippableVisibility; // 0x1258(0x08)
	struct UEquippableMinimapDisplayComponentDeprecated* EquippableMinimapDisplay; // 0x1260(0x08)
	struct UEquipmentChargeComponent* EquipmentCharge; // 0x1268(0x08)
	struct USpawnActorStateComponent* SpawnSmokeManager; // 0x1270(0x08)
	struct TArray<struct FVector> VerifiedSmokes; // 0x1278(0x10)

	void ReceiveBeginPlay(); // Function Ability_Sarge_4_MapTargetSmoke_Production.Ability_Sarge_4_MapTargetSmoke_Production_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__SpawnSmokeManager_K2Node_ComponentBoundEvent_7_OnSpawnActor__DelegateSignature(struct USpawnActorStateComponent* SpawnState, struct AActor* SpawnedActor); // Function Ability_Sarge_4_MapTargetSmoke_Production.Ability_Sarge_4_MapTargetSmoke_Production_C.BndEvt__SpawnSmokeManager_K2Node_ComponentBoundEvent_7_OnSpawnActor__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void ClientItemUnEquipped(); // Function Ability_Sarge_4_MapTargetSmoke_Production.Ability_Sarge_4_MapTargetSmoke_Production_C.ClientItemUnEquipped // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x19e0c40
	void ClientItemEquipped(); // Function Ability_Sarge_4_MapTargetSmoke_Production.Ability_Sarge_4_MapTargetSmoke_Production_C.ClientItemEquipped // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__SpawnSmokeManager_K2Node_ComponentBoundEvent_1_OnStateEnterSignature__DelegateSignature(struct UScriptStateComponent* EnteredState, struct UStateTransitionContext* StateTransitionContext, float StartTimeOffset); // Function Ability_Sarge_4_MapTargetSmoke_Production.Ability_Sarge_4_MapTargetSmoke_Production_C.BndEvt__SpawnSmokeManager_K2Node_ComponentBoundEvent_1_OnStateEnterSignature__DelegateSignature // (BlueprintEvent) // @ game+0x19e0c40
	void BndEvt__Ability_Sarge_4_MapTargetSmoke_Production_MapTargetingState_K2Node_ComponentBoundEvent_0_OnMapLocationSelectedSignature__DelegateSignature(struct TArray<struct FVector>& WorldLocations); // Function Ability_Sarge_4_MapTargetSmoke_Production.Ability_Sarge_4_MapTargetSmoke_Production_C.BndEvt__Ability_Sarge_4_MapTargetSmoke_Production_MapTargetingState_K2Node_ComponentBoundEvent_0_OnMapLocationSelectedSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x19e0c40
	void ExecuteUbergraph_Ability_Sarge_4_MapTargetSmoke_Production(int32_t EntryPoint); // Function Ability_Sarge_4_MapTargetSmoke_Production.Ability_Sarge_4_MapTargetSmoke_Production_C.ExecuteUbergraph_Ability_Sarge_4_MapTargetSmoke_Production // (Final|UbergraphFunction|HasDefaults) // @ game+0x19e0c40
};

